//package edu.xja.seats;
//
//import edu.xja.seats.controller.SeatController;
//import edu.xja.seats.pojo.ComboValue;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.springframework.amqp.core.*;
//import org.springframework.amqp.rabbit.core.RabbitAdmin;
//import org.springframework.amqp.rabbit.core.RabbitTemplate;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.test.context.junit4.SpringRunner;
//
//import java.nio.channels.Channel;
//import java.text.ParseException;
//import java.text.SimpleDateFormat;
//import java.util.Date;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
//@RunWith(SpringRunner.class)
//@SpringBootTest
//public class SeatsApplicationTests {
//    @Autowired
//    AmqpTemplate amqpTemplate;
//    @Autowired
//    AmqpAdmin amqpAdmin;
//    @Autowired
//    RabbitTemplate rabbitTemplate;
//    @Autowired
//    SeatController seatController;
//
//    @Test
//    public void contextLoads() {
//        //发送
//        //自动序列化
//        rabbitTemplate.convertAndSend("test","haha","yzk123");
//    }
////创建路由 queue
//    @Test
//    public void rabit() {
////        amqpAdmin.declareExchange(new DirectExchange("test"));
//////        amqpAdmin.declareQueue(new Queue("test"));
//        amqpAdmin.declareBinding(new Binding("test",Binding.DestinationType.QUEUE,"test","haha",null));
//        System.out.println("创建完成");
//    }
//    //消费
//    @Test
//    public  void  receive(){
//        //自动序列化
//       Object o= rabbitTemplate.receiveAndConvert("SeatDlQueue");
//        System.out.println(o);
//
//    }
//    @Test
//    public  void  time() throws ParseException {
//        Date date = new Date();
//
//        SimpleDateFormat simpleFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//        String today1 = simpleFormat.format(date);
//
//        Date fromDate3 = simpleFormat.parse("2020-05-01 14:25:50");
//        Date toDate3 = simpleFormat.parse(today1);
//
//        long from3 = fromDate3.getTime();
//        long to3 = toDate3.getTime();
//        int minutes = (int) ((to3 - from3) / (1000 * 60));
//        System.out.println("两个时间之间的分钟差为：" + minutes);
//
//        System.out.println("两个时间之间的分钟差为：" + minutes);
//    }
//
//
//}
