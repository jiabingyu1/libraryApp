package edu.xja.seats.service;

import edu.xja.seats.pojo.Choice;
import edu.xja.seats.pojo.Seat;
import edu.xja.seats.pojo.Seatchoiceadmin;
import edu.xja.seats.pojo.User;

import java.util.List;

public interface SeatService {

    int cancelSeat(String studentno);

    int updateBatch(List<Seat> list);

    int batchInsert(List<Seat> list);

    int updateSeat(Seat seat);

    int updateSeatED();

    Seat findOneSeat(Seat seat);

    List<Seat> findSeat(Seat seat);

    int insertOrUpdate(Seat record);

    int insertOrUpdateSelective(Seat record);

    List<Seat> findAllSeat();


    void deleAllseats();

    List<Seatchoiceadmin> adminSeatList();
}
