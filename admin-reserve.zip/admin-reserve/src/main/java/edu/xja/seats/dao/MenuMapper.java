package edu.xja.seats.dao;

import edu.xja.seats.pojo.Menu;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.Mapper;

public interface MenuMapper extends Mapper<Menu> {
    int updateBatch(List<Menu> list);

    int batchInsert(@Param("list") List<Menu> list);

    int insertOrUpdate(Menu record);

    int insertOrUpdateSelective(Menu record);
}