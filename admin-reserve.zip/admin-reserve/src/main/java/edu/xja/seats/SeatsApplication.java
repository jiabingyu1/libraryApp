package edu.xja.seats;

import org.springframework.amqp.rabbit.annotation.EnableRabbit;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import tk.mybatis.spring.annotation.MapperScan;
//RabbitListener+EnableRabbit来监听
@EnableRabbit
@SpringBootApplication()
@MapperScan(basePackages = {"edu.xja.seats.dao"})
public class SeatsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SeatsApplication.class, args);
	}



}
