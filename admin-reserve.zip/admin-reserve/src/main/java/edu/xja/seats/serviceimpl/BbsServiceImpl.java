package edu.xja.seats.serviceimpl;

import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import edu.xja.seats.pojo.Bbs;
import edu.xja.seats.dao.BbsMapper;
import edu.xja.seats.service.BbsService;
@Service
public class BbsServiceImpl implements BbsService{

    @Resource
    private BbsMapper bbsMapper;

    @Override
    public int updateBatch(List<Bbs> list) {
        return bbsMapper.updateBatch(list);
    }

    @Override
    public int batchInsert(List<Bbs> list) {
        return bbsMapper.batchInsert(list);
    }

    @Override
    public int insertOrUpdate(Bbs record) {
        return bbsMapper.insertOrUpdate(record);
    }

    @Override
    public int insertOrUpdateSelective(Bbs record) {
        return bbsMapper.insertOrUpdateSelective(record);
    }

}
