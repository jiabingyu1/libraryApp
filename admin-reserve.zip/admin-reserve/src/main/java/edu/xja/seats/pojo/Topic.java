package edu.xja.seats.pojo;

import javax.persistence.*;

@Table(name = "topic")
public class Topic {
    /**
     * 主键
     */
    @Id
    @Column(name = "id")
    @GeneratedValue(generator = "JDBC")
    private Integer id;

    /**
     * 对应的论坛主题ID
     */
    @Column(name = "bbsid")
    private Integer bbsid;

    /**
     * 内容
     */
    @Column(name = "content")
    private String content;

    /**
     * 发表人
     */
    @Column(name = "author")
    private String author;

    /**
     * 时间
     */
    @Column(name = "`time`")
    private String time;

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取对应的论坛主题ID
     *
     * @return bbsid - 对应的论坛主题ID
     */
    public Integer getBbsid() {
        return bbsid;
    }

    /**
     * 设置对应的论坛主题ID
     *
     * @param bbsid 对应的论坛主题ID
     */
    public void setBbsid(Integer bbsid) {
        this.bbsid = bbsid;
    }

    /**
     * 获取内容
     *
     * @return content - 内容
     */
    public String getContent() {
        return content;
    }

    /**
     * 设置内容
     *
     * @param content 内容
     */
    public void setContent(String content) {
        this.content = content;
    }

    /**
     * 获取发表人
     *
     * @return author - 发表人
     */
    public String getAuthor() {
        return author;
    }

    /**
     * 设置发表人
     *
     * @param author 发表人
     */
    public void setAuthor(String author) {
        this.author = author;
    }

    /**
     * 获取时间
     *
     * @return time - 时间
     */
    public String getTime() {
        return time;
    }

    /**
     * 设置时间
     *
     * @param time 时间
     */
    public void setTime(String time) {
        this.time = time;
    }
}