//package edu.xja.seats.utils;
//
//import edu.xja.seats.pojo.Choice;
//import edu.xja.seats.pojo.Illegal;
//import edu.xja.seats.service.IllegalService;
//import edu.xja.seats.service.SeatService;
//import org.springframework.amqp.rabbit.annotation.RabbitListener;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.text.ParseException;
//import java.text.SimpleDateFormat;
//import java.util.Date;
//
//@Service
//public class RabbitSeat {
//    @Autowired
//    SeatService seatService;
//    @Autowired
//    IllegalService illegalService;
//
//    @RabbitListener(queues = "SeatDlQueue")
//    public void reccive(Choice choice) {
//        Date date = new Date();
//        SimpleDateFormat simpleFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//        String newTime = simpleFormat.format(date);
//        System.out.println(timeDifference(choice.getTime())+"aaaaaaaa");
//        if (Integer.valueOf(choice.getStatus())== 2 && timeDifference(choice.getTime()) >=0) {
//            illegalService.illegaSet(choice.getId());
//            Illegal illegal = new Illegal();
//            illegal.setChoiceId(choice.getId());
//            illegal.setScore(20);
//            illegal.setRemarks("未能及时返回");
//            illegal.setTime(newTime);
//            illegal.setStudentno(choice.getStudentno());
//            illegalService.addIllega(illegal);
//        }else if(Integer.valueOf(choice.getStatus())== 0 && timeDifference(choice.getTime())>=6){
//            illegalService.illegaSet(choice.getId());
//            Illegal illegal = new Illegal();
//            illegal.setChoiceId(choice.getId());
//            illegal.setScore(20);
//            illegal.setRemarks("未能及时签到");
//            illegal.setTime(newTime);
//            illegal.setStudentno(choice.getStudentno());
//            illegalService.addIllega(illegal);
//        }
//
//    }
//
//    public int timeDifference(String pastTime) {
//        Date date = new Date();
//
//        SimpleDateFormat simpleFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//        String newTime = simpleFormat.format(date);
//        System.out.println(pastTime+"                            "+newTime);
//        try {
//            Date pastTime1   = simpleFormat.parse(pastTime);
//            Date newTime1 = simpleFormat.parse(newTime);
//            long pastTime2 = pastTime1.getTime();
//            long newTime2 = newTime1.getTime();
//            int minutes = (int) ((newTime2 - pastTime2) / (1000 * 60));
//            return minutes;
//        } catch (ParseException e) {
//            return 0;
//        }
//
//
//    }
//}
