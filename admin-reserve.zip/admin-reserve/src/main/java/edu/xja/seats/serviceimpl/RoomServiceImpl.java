package edu.xja.seats.serviceimpl;

import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import edu.xja.seats.pojo.Room;
import edu.xja.seats.dao.RoomMapper;
import edu.xja.seats.service.RoomService;
@Service
public class RoomServiceImpl implements RoomService{

    @Resource
    private RoomMapper roomMapper;

    @Override
    public int updateBatch(List<Room> list) {
        return roomMapper.updateBatch(list);
    }

    @Override
    public int batchInsert(List<Room> list) {
        return roomMapper.batchInsert(list);
    }

    @Override
    public int insertOrUpdate(Room record) {
        return roomMapper.insertOrUpdate(record);
    }

    @Override
    public Room findRoomByRoomId(int roomid) {
        return roomMapper.selectByPrimaryKey(roomid);
    }

    @Override
    public List<Room> findRoom(Room room) {
        return roomMapper.select(room);
    }

    @Override
    public int insertOrUpdateSelective(Room record) {
        return roomMapper.insertOrUpdateSelective(record);
    }

    @Override
    public int findRoomScore(int typeId) {
        return roomMapper.findRoomScore(typeId);
    }

    @Override
    public List<Room> findAll() {
        return roomMapper.selectAll();
    }

    @Override
    public int updateRoom(Room room) {

        return  roomMapper.updateByPrimaryKeySelective(room);
    }

    @Override
    public int addRoom(Room room) {
        return roomMapper.insert(room);
    }

    @Override
    public int deleteRoom(Room room) {
        return  roomMapper.delete(room);
    }

}
