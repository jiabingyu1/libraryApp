package edu.xja.seats.serviceimpl;

import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import edu.xja.seats.dao.TopicMapper;
import edu.xja.seats.pojo.Topic;
import edu.xja.seats.service.TopicService;
@Service
public class TopicServiceImpl implements TopicService{

    @Resource
    private TopicMapper topicMapper;

    @Override
    public int updateBatch(List<Topic> list) {
        return topicMapper.updateBatch(list);
    }

    @Override
    public int batchInsert(List<Topic> list) {
        return topicMapper.batchInsert(list);
    }

    @Override
    public int insertOrUpdate(Topic record) {
        return topicMapper.insertOrUpdate(record);
    }

    @Override
    public int insertOrUpdateSelective(Topic record) {
        return topicMapper.insertOrUpdateSelective(record);
    }

}
