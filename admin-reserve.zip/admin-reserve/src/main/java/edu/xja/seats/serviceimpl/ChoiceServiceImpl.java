package edu.xja.seats.serviceimpl;

import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import edu.xja.seats.dao.ChoiceMapper;
import edu.xja.seats.pojo.Choice;
import edu.xja.seats.service.ChoiceService;
@Service
public class ChoiceServiceImpl implements ChoiceService{

    @Resource
    private ChoiceMapper choiceMapper;

    @Override
    public int updateBatch(List<Choice> list) {
        return choiceMapper.updateBatch(list);
    }

    @Override
    public List<Choice> findOneChoice(Choice choice) {

        return choiceMapper.select(choice);
    }

    @Override
    public int batchInsert(List<Choice> list) {
        return choiceMapper.batchInsert(list);
    }

    @Override
    public int insertOrUpdate(Choice record) {
        return choiceMapper.insertOrUpdate(record);
    }

    @Override
    public int insertOrUpdateSelective(Choice record) {
        return choiceMapper.insertOrUpdateSelective(record);
    }

    @Override
    public int deleSeat(Choice choice) {
        return choiceMapper.delete(choice);
    }

    @Override
    public List<Choice> seleChoice(String time) {
        return choiceMapper.seleChoice(time);
    }

    @Override
    public int updateOne(Choice choice) {
        return choiceMapper.updateByPrimaryKey(choice);
    }

    @Override
    public Choice findOneByPrimKey(int choiceId) {
        return  choiceMapper.selectByPrimaryKey(choiceId);
    }

}
