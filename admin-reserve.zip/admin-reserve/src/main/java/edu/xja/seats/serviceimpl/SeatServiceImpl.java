package edu.xja.seats.serviceimpl;

import edu.xja.seats.pojo.Choice;
import edu.xja.seats.pojo.Seatchoiceadmin;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import edu.xja.seats.pojo.Seat;
import java.util.List;
import edu.xja.seats.dao.SeatMapper;
import edu.xja.seats.service.SeatService;
@Service
public class SeatServiceImpl implements SeatService{

    @Resource
    private SeatMapper seatMapper;

    @Override
    public int updateBatch(List<Seat> list) {
        return seatMapper.updateBatch(list);
    }

    @Override
    public int batchInsert(List<Seat> list) {
        return seatMapper.batchInsert(list);
    }

    @Override
    public int updateSeat(Seat seat) {
        return seatMapper.updateByPrimaryKey(seat);
    }

    @Override
    public int updateSeatED() {
        return seatMapper.updateSeatED();
    }

    @Override
    public Seat  findOneSeat(Seat seat) {
        return seatMapper.selectOne(seat);
    }

    @Override
    public List<Seat> findSeat(Seat seat) {
        return seatMapper.select(seat);
    }

    @Override
    public int insertOrUpdate(Seat record) {
        return seatMapper.insertOrUpdate(record);
    }

    @Override
    public int insertOrUpdateSelective(Seat record) {
        return seatMapper.insertOrUpdateSelective(record);
    }

    @Override
    public List<Seat> findAllSeat() {
        return seatMapper.selectAll();
    }

    @Override
    public int cancelSeat(String stu){
        return seatMapper.cancelSeat(stu);
    }

    @Override
    public void deleAllseats() {
        seatMapper.deleAllseats();
    }

    @Override
    public List<Seatchoiceadmin> adminSeatList() {
        return seatMapper.adminSeatList();
    }
}
