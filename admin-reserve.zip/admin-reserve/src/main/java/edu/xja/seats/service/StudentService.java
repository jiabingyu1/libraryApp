package edu.xja.seats.service;

import java.util.List;
import edu.xja.seats.pojo.Student;
import edu.xja.seats.pojo.Teacher;

public interface StudentService{


    int updateBatch(List<Student> list);

    int batchInsert(List<Student> list);

    int insertOrUpdate(Student record);

    int insertOrUpdateSelective(Student record);

    Student findOneStudent(Student student);

}
