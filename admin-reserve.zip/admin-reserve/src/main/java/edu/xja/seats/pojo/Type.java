package edu.xja.seats.pojo;

import javax.persistence.*;

@Table(name = "`type`")
public class Type {
    /**
     * 类型
     */
    @Id
    @Column(name = "id")
    @GeneratedValue(generator = "JDBC")
    private Integer id;

    /**
     * ID
     */
    @Column(name = "`name`")
    private String name;

    /**
     * 最低分数
     */
    @Column(name = "score")
    private Integer score;

    /**
     * 获取类型
     *
     * @return id - 类型
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置类型
     *
     * @param id 类型
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取ID
     *
     * @return name - ID
     */
    public String getName() {
        return name;
    }

    /**
     * 设置ID
     *
     * @param name ID
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * 获取最低分数
     *
     * @return score - 最低分数
     */
    public Integer getScore() {
        return score;
    }

    /**
     * 设置最低分数
     *
     * @param score 最低分数
     */
    public void setScore(Integer score) {
        this.score = score;
    }
}