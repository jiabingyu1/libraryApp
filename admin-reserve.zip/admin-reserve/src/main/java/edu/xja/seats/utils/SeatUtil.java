package edu.xja.seats.utils;

// 两个定时器


import edu.xja.seats.common.response.QueryResult;
import edu.xja.seats.pojo.*;
import edu.xja.seats.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ansi.AnsiOutput;
import org.springframework.context.annotation.PropertySource;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Component
@RestController
@EnableScheduling
public class SeatUtil {
    @Autowired
    private SeatService seatService;
    @Autowired
    private QueryResult queryResult;
    @Autowired
    private ChoiceService choiceService;
    @Autowired
    private ScoreService scoreService;
    @Autowired
    private IllegalService illegalService;

    //每天晚上11点生成更新所有座位信息
   // @Scheduled(cron = "0 0 22 * * ?")
    public void addNewSeat() {

        seatService.updateSeatED();
    }

    public void addNewSeat(Room room) {
        try {
            Date today = new Date();  //今天日期Date类型
            Date dayAfterTomorrow = getNextNextDay(today, 1); //后面的参数表示与今天的间隔，如1表示明天，2表示后天
            String date = new SimpleDateFormat("yyyy-MM-dd").format(dayAfterTomorrow);  //后天日期yyy-MM-dd string类型
            String time = "7点-21点";
            //所有的房间
            int roomid = room.getId();
            int row = room.getRow();
            int col = room.getCol();
            for (int k = 1; k <= row; k++) {                 //行
                for (int l = 1; l <= col; l++) {             //列
                    Seat seat = new Seat();
                    seat.setCol(l);
                    seat.setDate(date);
                    seat.setRoomid(roomid);
                    seat.setRow(k);
                    seat.setTime(time);
                    seat.setKeyword(date + "-" + time + "-" + roomid + "-" + k + "-" + l);
                    seat.setStudentno("1");
                    seatService.insertOrUpdate(seat);
                }
            }


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //每天晚上11点更新座位信息
    @Scheduled(cron = "0 0 22 * * ?")
    @GetMapping("test1")
    public QueryResult updaAllSeatDate() {
        Date todayDate = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd  HH:mm:ss");
        String today = sdf.format(todayDate);
        String today2 = sdf1.format(todayDate);
        Date today1 = new Date();  //今天日期Date类型
        Date dayAfterTomorrow = getNextNextDay(today1, 1); //后面的参数表示与今天的间隔，如1表示明天，2表示后天
        String date = new SimpleDateFormat("yyyy-MM-dd").format(dayAfterTomorrow);
        List<Seat> seatList = seatService.findAllSeat();
        System.out.println(seatList.size());
        List<String> user = new ArrayList<>();
        /* 更新座位信息，并记录没有签退的同学信息*/
        for (int i = 0; i < seatList.size(); i++) {
            String keyword = date + "-7点-22点" + seatList.get(i).getRoomid() + "-" + seatList.get(i).getRow() + "-" + seatList.get(i).getCol();
            seatList.get(i).setDate(date);
            seatList.get(i).setKeyword(keyword);
            if (!seatList.get(i).getStudentno().equals("1")) {
                user.add(seatList.get(i).getStudentno());
                seatList.get(i).setStudentno("1");
            }
            seatService.updateSeat(seatList.get(i));
        }
        for (int h = 0; h < user.size(); h++) {
            Score score = new Score();
            score.setStudentno(user.get(h));
            Score score1 = scoreService.findOneScore(score);
            score1.setTotal(score1.getTotal() - 20);
            System.out.println(score.getTotal());
            scoreService.updatScoer(score1);

        }
        List<Choice> choiceList = choiceService.seleChoice(today);
        for (int j = 0; j < choiceList.size(); j++) {
              boolean a =  choiceList.get(j).getStatus().equals("4") || choiceList.get(j).getStatus().equals("5")||choiceList.get(j).getStatus().equals("6");
            if (!a) {
                choiceList.get(j).setStatus("6");
                choiceService.updateOne(choiceList.get(j));
                Illegal illegal = new Illegal();
                illegal.setStudentno(choiceList.get(j).getStudentno());
                illegal.setRemarks("未签退");
                illegal.setTime(today2);
                illegal.setScore(20);
                illegal.setChoiceId(choiceList.get(j).getId());
                illegalService.addIllega(illegal);
            }
        }


        queryResult.setList(user);
        queryResult.setTotal(user.size());
        return queryResult;

    }

    /*@Scheduled(cron = "0 0/21 8-21 * * ?")
    @GetMapping("test2")
    public QueryResult updaSeat() {
        System.out.println("运行了1111 ");
        Date todayDate = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String today = sdf.format(todayDate);
       List<Choice>  choiceList= choiceService.seleChoice(today);
        List<String> user = new ArrayList<>();
        *//* 更新座位信息，并记录没有签退的同学信息*//*
        for (int i = 0; i < choiceList.size(); i++) {
            if (choiceList.get(i).getStatus().equals("0")) {
                System.out.println("aaa");
                user.add(choiceList.get(i).getStudentno());
                 choiceList.get(i).setStatus("6");
                 choiceService.updateOne(choiceList.get(i));
                 Seat seat = new Seat();
                 seat.setStudentno(choiceList.get(i).getStudentno());
                seatService.cancelSeat(choiceList.get(i).getStudentno());
                Illegal illegal = new Illegal();
                illegal.setStudentno(choiceList.get(i).getStudentno());
                illegal.setRemarks("未签到");
                illegal.setTime(sdf1.format(todayDate));
                illegal.setScore(20);
                illegal.setChoiceId(choiceList.get(i).getId());
                illegalService.addIllega(illegal);
                Score score = new Score();
                score.setStudentno(choiceList.get(i).getStudentno());
                Score score1 = scoreService.findOneScore(score);
                score1.setTotal(score1.getTotal() - 20);
                System.out.println(score.getTotal());
                scoreService.updatScoer(score1);
            }

        }
      queryResult.setMsg("操作成功");
        return queryResult;

    }*/


    // 在浏览器输入http://127.0.0.1:8080/LibrarySeats/newSeat.htm即可手动生成座位数
    @RequestMapping("newSeat")
    @ResponseBody
    public String today() {
        Thread thread = new Thread(new Task());
        thread.start();
        return "开始创建当日座位信息，请不要重复运行，观察控制台运行停止后可以登录后台查看座位信息！";
    }

    // 获取后天日期
    public static Date getNextNextDay(Date date, int day) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DAY_OF_MONTH, day);
        date = calendar.getTime();
        return date;
    }

    // 每天的整点 运行一次，将之前的占座取消
    //  @Scheduled(cron = "0 0 8,9,10，11，12，13，14，15，16，17，18，19，20，21 * * ?")
    public void updateChoice() {
/*	try {
			String now = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
			Choice choice = new Choice();
			choice.setTime(now);
			choiceService.modifyChoice(choice);
		} catch (Exception e) {
			e.printStackTrace();*/
    }


    public class Task implements Runnable {

        @Override
        public void run() {
            // TODO Auto-generated method stub
            addNewSeat();
        }


    }


}

