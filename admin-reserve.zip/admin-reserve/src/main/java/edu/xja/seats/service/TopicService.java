package edu.xja.seats.service;

import java.util.List;
import edu.xja.seats.pojo.Topic;
public interface TopicService{


    int updateBatch(List<Topic> list);

    int batchInsert(List<Topic> list);

    int insertOrUpdate(Topic record);

    int insertOrUpdateSelective(Topic record);

}
