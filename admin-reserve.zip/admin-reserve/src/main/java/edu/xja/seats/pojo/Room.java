package edu.xja.seats.pojo;

import javax.persistence.*;

@Table(name = "room")
public class Room {
    /**
     * 阅览室主键
     */
    @Id
    @Column(name = "id")
    @GeneratedValue(generator = "JDBC")
    private Integer id;

    /**
     * 阅览室类型
     */
    @Column(name = "typeid")
    private Integer typeid;

    /**
     * 名称
     */
    @Column(name = "`name`")
    private String name;

    /**
     * 行数
     */
    @Column(name = "`row`")
    private Integer row;

    /**
     * 列数
     */
    @Column(name = "col")
    private Integer col;

    /**
     * 总数
     */
    @Column(name = "total")
    private Integer total;
    private  Integer available;

    public Integer getAvailable() {
        return available;
    }

    public void setAvailable(Integer available) {
        this.available = available;
    }

    /**
     * 获取阅览室主键
     *
     * @return id - 阅览室主键
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置阅览室主键
     *
     * @param id 阅览室主键
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取阅览室类型
     *
     * @return typeid - 阅览室类型
     */
    public Integer getTypeid() {
        return typeid;
    }

    /**
     * 设置阅览室类型
     *
     * @param typeid 阅览室类型
     */
    public void setTypeid(Integer typeid) {
        this.typeid = typeid;
    }

    /**
     * 获取名称
     *
     * @return name - 名称
     */
    public String getName() {
        return name;
    }

    /**
     * 设置名称
     *
     * @param name 名称
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * 获取行数
     *
     * @return row - 行数
     */
    public Integer getRow() {
        return row;
    }

    /**
     * 设置行数
     *
     * @param row 行数
     */
    public void setRow(Integer row) {
        this.row = row;
    }

    /**
     * 获取列数
     *
     * @return col - 列数
     */
    public Integer getCol() {
        return col;
    }

    /**
     * 设置列数
     *
     * @param col 列数
     */
    public void setCol(Integer col) {
        this.col = col;
    }

    /**
     * 获取总数
     *
     * @return total - 总数
     */
    public Integer getTotal() {
        return total;
    }

    /**
     * 设置总数
     *
     * @param total 总数
     */
    public void setTotal(Integer total) {
        this.total = total;
    }
}