package edu.xja.seats.service;

import java.util.List;

import edu.xja.seats.pojo.Clazz;

public interface ClazzService {


    int updateBatch(List<Clazz> list);

    int batchInsert(List<Clazz> list);

    int insertOrUpdate(Clazz record);

    int insertOrUpdateSelective(Clazz record);

    Clazz findOneClazz(Clazz clazz);

}
