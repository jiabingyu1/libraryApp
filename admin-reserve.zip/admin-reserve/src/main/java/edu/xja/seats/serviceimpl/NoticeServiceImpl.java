package edu.xja.seats.serviceimpl;

import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import edu.xja.seats.dao.NoticeMapper;
import edu.xja.seats.pojo.Notice;
import edu.xja.seats.service.NoticeService;
@Service
public class NoticeServiceImpl implements NoticeService{

    @Resource
    private NoticeMapper noticeMapper;

    @Override
    public List<Notice> selectNotice() {
        return noticeMapper.selectNotice();
    }

    @Override
    public int updateBatch(List<Notice> list) {
        return noticeMapper.updateBatch(list);
    }

    @Override
    public int batchInsert(List<Notice> list) {
        return noticeMapper.batchInsert(list);
    }

    @Override
    public int insertOrUpdate(Notice record) {
        return noticeMapper.insertOrUpdate(record);
    }

    @Override
    public int insertOrUpdateSelective(Notice record) {
        return noticeMapper.insertOrUpdateSelective(record);
    }

}
