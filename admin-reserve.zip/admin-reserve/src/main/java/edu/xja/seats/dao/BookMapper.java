package edu.xja.seats.dao;

import edu.xja.seats.pojo.Book;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.Mapper;

public interface BookMapper extends Mapper<Book> {
    int updateBatch(List<Book> list);

    int batchInsert(@Param("list") List<Book> list);

    int insertOrUpdate(Book record);

    int insertOrUpdateSelective(Book record);
}