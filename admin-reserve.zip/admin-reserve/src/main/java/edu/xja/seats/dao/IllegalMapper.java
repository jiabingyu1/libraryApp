package edu.xja.seats.dao;

import edu.xja.seats.pojo.Illegal;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.Mapper;

public interface IllegalMapper extends Mapper<Illegal> {
    int updateBatch(List<Illegal> list);

    int batchInsert(@Param("list") List<Illegal> list);

    int insertOrUpdate(Illegal record);

    int insertOrUpdateSelective(Illegal record);

    int illegaSet(int choiceId);


}