package edu.xja.seats.config;

import org.springframework.amqp.core.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SeatQueueConfig {
  @Bean
    DirectExchange EmailExchange() {
        return new DirectExchange("SeatExchange");
    }

    @Bean
    DirectExchange SeatDlExchange() {
        return new DirectExchange("SeatDlExchange");
    }

    @Bean
    Queue EmailQueue() {
        return QueueBuilder.durable("SeatQueue")
                .withArgument("x-dead-letter-exchange", "SeatDlExchange")
                .withArgument("x-dead-letter-routing-key", "SeatDl")
                .withArgument("x-message-ttl", 6000)
                .build();
    }

    @Bean
    Queue SeatDlQueue() {
        return new Queue("SeatDlQueue", true);
    }

    @Bean
    Binding BindingSeatDl() {
        return BindingBuilder.bind(EmailQueue()).to(EmailExchange()).with("SeatKey");
    }

    @Bean
    Binding BindEmail() {
        return BindingBuilder.bind(SeatDlQueue()).to(SeatDlExchange()).with("SeatDl");
    }

}
