package edu.xja.seats.serviceimpl;

import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import edu.xja.seats.pojo.Student;
import edu.xja.seats.dao.StudentMapper;
import edu.xja.seats.service.StudentService;
@Service
public class
StudentServiceImpl implements StudentService{

    @Resource
    private StudentMapper studentMapper;

    @Override
    public int updateBatch(List<Student> list) {
        return studentMapper.updateBatch(list);
    }

    @Override
    public int batchInsert(List<Student> list) {
        return studentMapper.batchInsert(list);
    }

    @Override
    public int insertOrUpdate(Student record) {
        return studentMapper.insertOrUpdate(record);
    }

    @Override
    public int insertOrUpdateSelective(Student record) {
        return studentMapper.insertOrUpdateSelective(record);
    }

    @Override
    public Student findOneStudent(Student student) {
        return studentMapper.selectOne(student);
    }

}
