package edu.xja.seats.dao;

import edu.xja.seats.pojo.Log;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.Mapper;

public interface LogMapper extends Mapper<Log> {
    int updateBatch(List<Log> list);

    int batchInsert(@Param("list") List<Log> list);

    int insertOrUpdate(Log record);

    int insertOrUpdateSelective(Log record);
}