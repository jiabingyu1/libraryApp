package edu.xja.seats.service;

import java.util.List;

import edu.xja.seats.pojo.Teacher;

public interface TeacherService {


    int updateBatch(List<Teacher> list);

    int batchInsert(List<Teacher> list);

    int insertOrUpdate(Teacher record);

    int insertOrUpdateSelective(Teacher record);

    Teacher findOneTeacher(Teacher teacher);

}
