package edu.xja.seats.pojo;

import javax.persistence.*;

@Table(name = "bbs")
public class Bbs {
    /**
     * 交流主键
     */
    @Id
    @Column(name = "id")
    @GeneratedValue(generator = "JDBC")
    private Integer id;

    /**
     * 标题
     */
    @Column(name = "title")
    private String title;

    /**
     * 学号或者工号
     */
    @Column(name = "author")
    private String author;

    /**
     * 创建时间
     */
    @Column(name = "`time`")
    private String time;

    /**
     * 回复数量
     */
    @Column(name = "reply")
    private Integer reply;

    /**
     * 最后回复人
     */
    @Column(name = "lastreply")
    private String lastreply;

    /**
     * 最后访问时间
     */
    @Column(name = "lastreplytime")
    private String lastreplytime;

    /**
     * 获取交流主键
     *
     * @return id - 交流主键
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置交流主键
     *
     * @param id 交流主键
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取标题
     *
     * @return title - 标题
     */
    public String getTitle() {
        return title;
    }

    /**
     * 设置标题
     *
     * @param title 标题
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * 获取学号或者工号
     *
     * @return author - 学号或者工号
     */
    public String getAuthor() {
        return author;
    }

    /**
     * 设置学号或者工号
     *
     * @param author 学号或者工号
     */
    public void setAuthor(String author) {
        this.author = author;
    }

    /**
     * 获取创建时间
     *
     * @return time - 创建时间
     */
    public String getTime() {
        return time;
    }

    /**
     * 设置创建时间
     *
     * @param time 创建时间
     */
    public void setTime(String time) {
        this.time = time;
    }

    /**
     * 获取回复数量
     *
     * @return reply - 回复数量
     */
    public Integer getReply() {
        return reply;
    }

    /**
     * 设置回复数量
     *
     * @param reply 回复数量
     */
    public void setReply(Integer reply) {
        this.reply = reply;
    }

    /**
     * 获取最后回复人
     *
     * @return lastreply - 最后回复人
     */
    public String getLastreply() {
        return lastreply;
    }

    /**
     * 设置最后回复人
     *
     * @param lastreply 最后回复人
     */
    public void setLastreply(String lastreply) {
        this.lastreply = lastreply;
    }

    /**
     * 获取最后访问时间
     *
     * @return lastreplytime - 最后访问时间
     */
    public String getLastreplytime() {
        return lastreplytime;
    }

    /**
     * 设置最后访问时间
     *
     * @param lastreplytime 最后访问时间
     */
    public void setLastreplytime(String lastreplytime) {
        this.lastreplytime = lastreplytime;
    }
}