package edu.xja.seats.dao;

import edu.xja.seats.pojo.Score;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.Mapper;

public interface ScoreMapper extends Mapper<Score> {
    int updateBatch(List<Score> list);

    int batchInsert(@Param("list") List<Score> list);

    int insertOrUpdate(Score record);

    int insertOrUpdateSelective(Score record);
}