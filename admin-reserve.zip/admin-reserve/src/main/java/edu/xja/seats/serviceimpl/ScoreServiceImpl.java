package edu.xja.seats.serviceimpl;

import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import edu.xja.seats.pojo.Score;

import java.net.Socket;
import java.util.List;
import edu.xja.seats.dao.ScoreMapper;
import edu.xja.seats.service.ScoreService;
@Service
public class ScoreServiceImpl implements ScoreService{

    @Resource
    private ScoreMapper scoreMapper;

    @Override
    public int updateBatch(List<Score> list) {
        return scoreMapper.updateBatch(list);
    }

    @Override
    public Score findOneScore(Score score) {
        return scoreMapper.selectOne(score);
    }

    @Override
    public int batchInsert(List<Score> list) {
        return scoreMapper.batchInsert(list);
    }

    @Override
    public int insertOrUpdate(Score record) {
        return scoreMapper.insertOrUpdate(record);
    }

    @Override
    public int insertOrUpdateSelective(Score record) {
        return scoreMapper.insertOrUpdateSelective(record);
    }

    @Override
    public int updatScoer(Score score) {
        return scoreMapper.updateByPrimaryKeySelective(score);
    }

}
