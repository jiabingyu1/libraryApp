package edu.xja.seats.service;

import java.util.List;
import edu.xja.seats.pojo.Bbs;
public interface BbsService{


    int updateBatch(List<Bbs> list);

    int batchInsert(List<Bbs> list);

    int insertOrUpdate(Bbs record);

    int insertOrUpdateSelective(Bbs record);

}
