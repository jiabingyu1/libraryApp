package edu.xja.seats.pojo;

import javax.persistence.*;

@Table(name = "book")
public class Book {
    /**
     * 书籍自增主键
     */
    @Id
    @Column(name = "id")
    @GeneratedValue(generator = "JDBC")
    private Integer id;

    /**
     * 书名
     */
    @Column(name = "`name`")
    private String name;

    /**
     * 作者
     */
    @Column(name = "author")
    private String author;

    /**
     * 出版社
     */
    @Column(name = "publish")
    private String publish;

    /**
     * 封面图片
     */
    @Column(name = "cover")
    private String cover;

    /**
     * 简介
     */
    @Column(name = "remarks")
    private String remarks;

    /**
     * 获取书籍自增主键
     *
     * @return id - 书籍自增主键
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置书籍自增主键
     *
     * @param id 书籍自增主键
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取书名
     *
     * @return name - 书名
     */
    public String getName() {
        return name;
    }

    /**
     * 设置书名
     *
     * @param name 书名
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * 获取作者
     *
     * @return author - 作者
     */
    public String getAuthor() {
        return author;
    }

    /**
     * 设置作者
     *
     * @param author 作者
     */
    public void setAuthor(String author) {
        this.author = author;
    }

    /**
     * 获取出版社
     *
     * @return publish - 出版社
     */
    public String getPublish() {
        return publish;
    }

    /**
     * 设置出版社
     *
     * @param publish 出版社
     */
    public void setPublish(String publish) {
        this.publish = publish;
    }

    /**
     * 获取封面图片
     *
     * @return cover - 封面图片
     */
    public String getCover() {
        return cover;
    }

    /**
     * 设置封面图片
     *
     * @param cover 封面图片
     */
    public void setCover(String cover) {
        this.cover = cover;
    }

    /**
     * 获取简介
     *
     * @return remarks - 简介
     */
    public String getRemarks() {
        return remarks;
    }

    /**
     * 设置简介
     *
     * @param remarks 简介
     */
    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
}