package edu.xja.seats.dao;

import edu.xja.seats.pojo.Clazz;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.Mapper;

public interface ClazzMapper extends Mapper<Clazz> {
    int updateBatch(List<Clazz> list);

    int batchInsert(@Param("list") List<Clazz> list);

    int insertOrUpdate(Clazz record);

    int insertOrUpdateSelective(Clazz record);
}