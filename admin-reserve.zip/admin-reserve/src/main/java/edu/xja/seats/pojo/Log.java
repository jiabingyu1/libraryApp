package edu.xja.seats.pojo;

import javax.persistence.*;

@Table(name = "log")
public class Log {
    /**
     * 日志
     */
    @Id
    @Column(name = "logId")
    @GeneratedValue(generator = "JDBC")
    private Long logid;

    /**
     * 操作人
     */
    @Column(name = "userName")
    private String username;

    /**
     * 时间
     */
    @Column(name = "createTime")
    private String createtime;

    /**
     * 详细
     */
    @Column(name = "content")
    private String content;

    /**
     * 操作类型（增删改）
     */
    @Column(name = "`operation`")
    private String operation;

    /**
     * IP地址
     */
    @Column(name = "ip")
    private String ip;

    /**
     * 所属模块
     */
    @Column(name = "`module`")
    private String module;

    /**
     * 获取日志
     *
     * @return logId - 日志
     */
    public Long getLogid() {
        return logid;
    }

    /**
     * 设置日志
     *
     * @param logid 日志
     */
    public void setLogid(Long logid) {
        this.logid = logid;
    }

    /**
     * 获取操作人
     *
     * @return userName - 操作人
     */
    public String getUsername() {
        return username;
    }

    /**
     * 设置操作人
     *
     * @param username 操作人
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * 获取时间
     *
     * @return createTime - 时间
     */
    public String getCreatetime() {
        return createtime;
    }

    /**
     * 设置时间
     *
     * @param createtime 时间
     */
    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    /**
     * 获取详细
     *
     * @return content - 详细
     */
    public String getContent() {
        return content;
    }

    /**
     * 设置详细
     *
     * @param content 详细
     */
    public void setContent(String content) {
        this.content = content;
    }

    /**
     * 获取操作类型（增删改）
     *
     * @return operation - 操作类型（增删改）
     */
    public String getOperation() {
        return operation;
    }

    /**
     * 设置操作类型（增删改）
     *
     * @param operation 操作类型（增删改）
     */
    public void setOperation(String operation) {
        this.operation = operation;
    }

    /**
     * 获取IP地址
     *
     * @return ip - IP地址
     */
    public String getIp() {
        return ip;
    }

    /**
     * 设置IP地址
     *
     * @param ip IP地址
     */
    public void setIp(String ip) {
        this.ip = ip;
    }

    /**
     * 获取所属模块
     *
     * @return module - 所属模块
     */
    public String getModule() {
        return module;
    }

    /**
     * 设置所属模块
     *
     * @param module 所属模块
     */
    public void setModule(String module) {
        this.module = module;
    }
}