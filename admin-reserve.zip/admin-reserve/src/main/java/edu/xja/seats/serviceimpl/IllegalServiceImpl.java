package edu.xja.seats.serviceimpl;

import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import edu.xja.seats.dao.IllegalMapper;
import edu.xja.seats.pojo.Illegal;
import edu.xja.seats.service.IllegalService;
@Service
public class IllegalServiceImpl implements IllegalService{

    @Resource
    private IllegalMapper illegalMapper;

    @Override
    public int updateBatch(List<Illegal> list) {
        return illegalMapper.updateBatch(list);
    }

    @Override
    public int batchInsert(List<Illegal> list) {
        return illegalMapper.batchInsert(list);
    }

    @Override
    public int insertOrUpdate(Illegal record) {
        return illegalMapper.insertOrUpdate(record);
    }

    @Override
    public int insertOrUpdateSelective(Illegal record) {
        return illegalMapper.insertOrUpdateSelective(record);
    }

    @Override
    public List<Illegal> findAllIllegal(Illegal illegal) {
        return illegalMapper.select(illegal);
    }

    @Override
    public int addIllega(Illegal illegal) {

        return illegalMapper.insert(illegal);
    }

    @Override
    public int deleIllega(Illegal illegal) {
        return illegalMapper.delete(illegal);
    }

    @Override
    public Illegal findOne(Illegal illegal) {
        return illegalMapper.selectOne(illegal);
    }

    @Override
    public int illegaSet(int choiceId) {
        return illegalMapper.illegaSet(choiceId);
    }

}
