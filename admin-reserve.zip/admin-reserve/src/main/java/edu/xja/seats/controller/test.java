package edu.xja.seats.controller;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class test {
    @Autowired
    RabbitTemplate rabbitTemplate;

    @GetMapping(value = "amqp")
    public String sedEmail(@RequestParam Map<String, Object> parms) {
        String msg = parms.get("msg").toString();

        for (int i = 0; i < 2000; i++) {
             int a=Integer.valueOf(msg)+i;
            System.out.println(msg);
            rabbitTemplate.convertAndSend("SeatExchange", "SeatKey", a);
        }
        return "ok";
    }

    @GetMapping(value = "amqp1")
    public String sendBlog(@RequestParam Map<String, Object> parms) {
        String msg = parms.get("msg").toString();
        rabbitTemplate.convertAndSend("BlogExchange", "blog.java", msg);
        return "ok";
    }
}
