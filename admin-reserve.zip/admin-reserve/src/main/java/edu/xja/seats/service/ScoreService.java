package edu.xja.seats.service;

import edu.xja.seats.pojo.Score;

import java.util.List;

public interface ScoreService {


    int updateBatch(List<Score> list);

    Score findOneScore(Score score);

    int batchInsert(List<Score> list);

    int insertOrUpdate(Score record);

    int insertOrUpdateSelective(Score record);
   int  updatScoer(Score score);
}
