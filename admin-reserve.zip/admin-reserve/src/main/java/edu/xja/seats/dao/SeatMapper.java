package edu.xja.seats.dao;

import edu.xja.seats.pojo.Choice;
import edu.xja.seats.pojo.Seat;

import java.util.List;

import edu.xja.seats.pojo.Seatchoiceadmin;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import tk.mybatis.mapper.common.Mapper;

public interface SeatMapper extends Mapper<Seat> {
    int updateBatch(List<Seat> list);

    int batchInsert(@Param("list") List<Seat> list);

    int insertOrUpdate(Seat record);

    int insertOrUpdateSelective(Seat record);

    int cancelSeat(String studentno);

    int updateSeatED();

    @Update("update seat.choice set status = 5 where status != 6;update seat.seat set studentno = '1'")
    void deleAllseats();

    @Select("select seat.choice.studentno, seat.choice.seatkeyword, " +
            "seat.choice.time, seat.choice.status, seat.seat.roomid, " +
            "seat.seat.row, seat.seat.col from seat.choice " +
            "JOIN seat.seat ON seat.seat.studentno = seat.choice.studentno where choice.status in (0,1,2,3,4)")
    List<Seatchoiceadmin> adminSeatList();
}