package edu.xja.seats.serviceimpl;

import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import edu.xja.seats.pojo.Type;
import edu.xja.seats.dao.TypeMapper;
import edu.xja.seats.service.TypeService;
@Service
public class TypeServiceImpl implements TypeService{

    @Resource
    private TypeMapper typeMapper;

    @Override
    public int updateBatch(List<Type> list) {
        return typeMapper.updateBatch(list);
    }

    @Override
    public int batchInsert(List<Type> list) {
        return typeMapper.batchInsert(list);
    }

    @Override
    public int insertOrUpdate(Type record) {
        return typeMapper.insertOrUpdate(record);
    }

    @Override
    public int insertOrUpdateSelective(Type record) {
        return typeMapper.insertOrUpdateSelective(record);
    }

}
