package edu.xja.seats.service;

import java.util.List;
import edu.xja.seats.pojo.Type;
public interface TypeService{


    int updateBatch(List<Type> list);

    int batchInsert(List<Type> list);

    int insertOrUpdate(Type record);

    int insertOrUpdateSelective(Type record);

}
