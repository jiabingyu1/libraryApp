package edu.xja.seats.service;

import java.util.List;
import edu.xja.seats.pojo.Book;
public interface BookService{


    int updateBatch(List<Book> list);

    int batchInsert(List<Book> list);

    int insertOrUpdate(Book record);

    int insertOrUpdateSelective(Book record);

}
