package edu.xja.seats.dao;

import edu.xja.seats.pojo.Bbs;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.Mapper;

public interface BbsMapper extends Mapper<Bbs> {
    int updateBatch(List<Bbs> list);

    int batchInsert(@Param("list") List<Bbs> list);

    int insertOrUpdate(Bbs record);

    int insertOrUpdateSelective(Bbs record);
}