package edu.xja.seats.service;

import java.util.List;

import edu.xja.seats.pojo.Choice;

public interface ChoiceService {


    int updateBatch(List<Choice> list);

    List<Choice> findOneChoice(Choice choice);

    int batchInsert(List<Choice> list);

    int insertOrUpdate(Choice record);

    int insertOrUpdateSelective(Choice record);

    int deleSeat(Choice choice);

    List<Choice> seleChoice(String time);

    int updateOne(Choice choice);

    Choice findOneByPrimKey(int choiceId);


}
