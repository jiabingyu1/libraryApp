package edu.xja.seats;

import edu.xja.seats.controller.RoomController;
import edu.xja.seats.controller.SeatController;
import edu.xja.seats.dao.ChoiceMapper;
import edu.xja.seats.pojo.Choice;
import edu.xja.seats.pojo.ComboValue;
import edu.xja.seats.serviceimpl.ChoiceServiceImpl;
import org.apache.ibatis.session.RowBounds;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class Test1 {


}