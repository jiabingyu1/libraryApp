package edu.xja.seats.dao;

import edu.xja.seats.pojo.Operation;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.Mapper;

public interface OperationMapper extends Mapper<Operation> {
    int updateBatch(List<Operation> list);

    int batchInsert(@Param("list") List<Operation> list);

    int insertOrUpdate(Operation record);

    int insertOrUpdateSelective(Operation record);
}