package edu.xja.seats.dao;

import edu.xja.seats.pojo.Type;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.Mapper;

public interface TypeMapper extends Mapper<Type> {
    int updateBatch(List<Type> list);

    int batchInsert(@Param("list") List<Type> list);

    int insertOrUpdate(Type record);

    int insertOrUpdateSelective(Type record);
}