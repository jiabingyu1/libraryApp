package edu.xja.seats.serviceimpl;

import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import edu.xja.seats.dao.MenuMapper;
import edu.xja.seats.pojo.Menu;
import edu.xja.seats.service.MenuService;
@Service
public class MenuServiceImpl implements MenuService{

    @Resource
    private MenuMapper menuMapper;

    @Override
    public int updateBatch(List<Menu> list) {
        return menuMapper.updateBatch(list);
    }

    @Override
    public int batchInsert(List<Menu> list) {
        return menuMapper.batchInsert(list);
    }

    @Override
    public int insertOrUpdate(Menu record) {
        return menuMapper.insertOrUpdate(record);
    }

    @Override
    public int insertOrUpdateSelective(Menu record) {
        return menuMapper.insertOrUpdateSelective(record);
    }

}
