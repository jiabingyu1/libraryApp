package edu.xja.seats.serviceimpl;

import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import edu.xja.seats.dao.OperationMapper;
import edu.xja.seats.pojo.Operation;
import edu.xja.seats.service.OperationService;
@Service
public class OperationServiceImpl implements OperationService{

    @Resource
    private OperationMapper operationMapper;

    @Override
    public int updateBatch(List<Operation> list) {
        return operationMapper.updateBatch(list);
    }

    @Override
    public int batchInsert(List<Operation> list) {
        return operationMapper.batchInsert(list);
    }

    @Override
    public int insertOrUpdate(Operation record) {
        return operationMapper.insertOrUpdate(record);
    }

    @Override
    public int insertOrUpdateSelective(Operation record) {
        return operationMapper.insertOrUpdateSelective(record);
    }

}
