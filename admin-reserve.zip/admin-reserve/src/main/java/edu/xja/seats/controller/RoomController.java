package edu.xja.seats.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import edu.xja.seats.common.response.QueryResult;
import edu.xja.seats.common.response.ResponseResult;
import edu.xja.seats.pojo.Room;
import edu.xja.seats.pojo.Seat;
import edu.xja.seats.service.RoomService;
import edu.xja.seats.service.SeatService;
import edu.xja.seats.utils.SeatUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

// 阅览室基本信息
@Api(value = "阅览室基本信息", tags = "阅览室基本信息")

@RestController
public class RoomController {


    @Autowired
    private RoomService roomService;
    @Autowired
    private SeatUtil seatUtil;
    @Autowired
    private SeatService seatService;
    @Autowired
    private QueryResult queryResult;


    @ApiOperation(value = "修改或增加")
    @PostMapping("reserveRoom")
    public ResponseResult reserveroom(Room room) {

        room.setTotal(room.getCol() * room.getRow());  //总座位数=列数     X 行数
        try {
            if (room.getId() != null) {
                roomService.updateRoom(room);//加锁

                seatUtil.addNewSeat(room);
                return ResponseResult.SUCCESS();
            } else {
                roomService.addRoom(room);//加锁

                seatUtil.addNewSeat(room);
                return ResponseResult.SUCCESS();
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseResult.FAIL();
        }
    }

    @ApiOperation(value = "删除")
    @PostMapping("deleteRoom")
    public ResponseResult delete(Room room) {
        try {
            roomService.deleteRoom(room);
            return ResponseResult.SUCCESS();
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseResult.FAIL();
        }
    }

    @ApiOperation(value = "查询教室可用座位和教室集合")
    @GetMapping("roomSeatNum")
    public QueryResult roomSeatNum() {
        List<Room> roomList = roomService.findAll();
      //  Map<Object, Integer> canUseNumList = new HashMap<>();
        List<Integer> canUseNumList =new ArrayList<>();
        for (int j = 0; j < roomList.size(); j++) {
            Seat seat = new Seat();
            seat.setRoomid(roomList.get(j).getId());
            int num = 0;
            List<Seat> list = seatService.findSeat(seat);
            for (int i = 0; i < list.size(); i++) {
                if (list.get(i).getStudentno().equals("1")) {
                    num++;
                }
            }
            roomList.get(j).setAvailable(num);

        }
        queryResult.setData(roomList);
        return queryResult;

    }


}
