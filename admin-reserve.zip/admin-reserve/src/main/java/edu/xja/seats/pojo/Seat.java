package edu.xja.seats.pojo;

import javax.persistence.*;

@Table(name = "seat")
public class Seat {
    /**
     * 座位信息主键
     */
    @Id
    @Column(name = "id")
    @GeneratedValue(generator = "JDBC")
    private Integer id;

    /**
     * 所属阅览室
     */
    @Column(name = "roomid")
    private Integer roomid;

    /**
     * 所属行
     */
    @Column(name = "`row`")
    private Integer row;

    /**
     * 所属列
     */
    @Column(name = "col")
    private Integer col;

    /**
     * 被占用学号，1表示未被占座，有学号表示被某个学生占座
     */
    @Column(name = "studentno")
    private String studentno;

    /**
     * 时间段
     */
    @Column(name = "`time`")
    private String time;

    /**
     * 日期
     */
    @Column(name = "`date`")
    private String date;

    /**
     * 关键字，由row,col,date,time,roomid组成
     */
    @Column(name = "keyword")
    private String keyword;

    /**
     * 获取座位信息主键
     *
     * @return id - 座位信息主键
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置座位信息主键
     *
     * @param id 座位信息主键
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取所属阅览室
     *
     * @return roomid - 所属阅览室
     */
    public Integer getRoomid() {
        return roomid;
    }

    /**
     * 设置所属阅览室
     *
     * @param roomid 所属阅览室
     */
    public void setRoomid(Integer roomid) {
        this.roomid = roomid;
    }

    /**
     * 获取所属行
     *
     * @return row - 所属行
     */
    public Integer getRow() {
        return row;
    }

    /**
     * 设置所属行
     *
     * @param row 所属行
     */
    public void setRow(Integer row) {
        this.row = row;
    }

    /**
     * 获取所属列
     *
     * @return col - 所属列
     */
    public Integer getCol() {
        return col;
    }

    /**
     * 设置所属列
     *
     * @param col 所属列
     */
    public void setCol(Integer col) {
        this.col = col;
    }

    /**
     * 获取被占用学号，1表示未被占座，有学号表示被某个学生占座
     *
     * @return studentno - 被占用学号，1表示未被占座，有学号表示被某个学生占座
     */
    public String getStudentno() {
        return studentno;
    }

    /**
     * 设置被占用学号，1表示未被占座，有学号表示被某个学生占座
     *
     * @param studentno 被占用学号，1表示未被占座，有学号表示被某个学生占座
     */
    public void setStudentno(String studentno) {
        this.studentno = studentno;
    }

    /**
     * 获取时间段
     *
     * @return time - 时间段
     */
    public String getTime() {
        return time;
    }

    /**
     * 设置时间段
     *
     * @param time 时间段
     */
    public void setTime(String time) {
        this.time = time;
    }

    /**
     * 获取日期
     *
     * @return date - 日期
     */
    public String getDate() {
        return date;
    }

    /**
     * 设置日期
     *
     * @param date 日期
     */
    public void setDate(String date) {
        this.date = date;
    }

    /**
     * 获取关键字，由row,col,date,time,roomid组成
     *
     * @return keyword - 关键字，由row,col,date,time,roomid组成
     */
    public String getKeyword() {
        return keyword;
    }

    /**
     * 设置关键字，由row,col,date,time,roomid组成
     *
     * @param keyword 关键字，由row,col,date,time,roomid组成
     */
    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }
}