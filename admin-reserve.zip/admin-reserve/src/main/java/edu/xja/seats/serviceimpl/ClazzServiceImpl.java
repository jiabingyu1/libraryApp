package edu.xja.seats.serviceimpl;

import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import edu.xja.seats.dao.ClazzMapper;
import java.util.List;
import edu.xja.seats.pojo.Clazz;
import edu.xja.seats.service.ClazzService;
@Service
public class ClazzServiceImpl implements ClazzService{

    @Resource
    private ClazzMapper clazzMapper;

    @Override
    public int updateBatch(List<Clazz> list) {
        return clazzMapper.updateBatch(list);
    }

    @Override
    public int batchInsert(List<Clazz> list) {
        return clazzMapper.batchInsert(list);
    }

    @Override
    public int insertOrUpdate(Clazz record) {
        return clazzMapper.insertOrUpdate(record);
    }

    @Override
    public int insertOrUpdateSelective(Clazz record) {
        return clazzMapper.insertOrUpdateSelective(record);
    }

    @Override
    public Clazz findOneClazz(Clazz clazz) {
        return clazzMapper.selectOne(clazz);
    }

}
