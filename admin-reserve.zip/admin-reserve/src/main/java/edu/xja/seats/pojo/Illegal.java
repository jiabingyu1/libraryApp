package edu.xja.seats.pojo;

import javax.persistence.*;

@Table(name = "illegal")
public class Illegal {
    /**
     * 违章信息ID
     */
    @Id
    @Column(name = "id")
    @GeneratedValue(generator = "JDBC")
    private Integer id;

    /**
     * 学号
     */
    @Column(name = "studentno")
    private String studentno;

    /**
     * 违章时间
     */
    @Column(name = "`time`")
    private String time;

    /**
     * 所扣分数
     */
    @Column(name = "score")
    private Integer score;

    /**
     * 违章简介
     */
    @Column(name = "remarks")
    private String remarks;
    @Column(name = "choiceId")
    private  int choiceId;

    public int getChoiceId() {
        return choiceId;
    }

    public void setChoiceId(int choiceId) {
        this.choiceId = choiceId;
    }

    /**
     * 获取违章信息ID
     *
     * @return id - 违章信息ID
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置违章信息ID
     *
     * @param id 违章信息ID
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取学号
     *
     * @return studentno - 学号
     */
    public String getStudentno() {
        return studentno;
    }

    /**
     * 设置学号
     *
     * @param studentno 学号
     */
    public void setStudentno(String studentno) {
        this.studentno = studentno;
    }

    /**
     * 获取违章时间
     *
     * @return time - 违章时间
     */
    public String getTime() {
        return time;
    }

    /**
     * 设置违章时间
     *
     * @param time 违章时间
     */
    public void setTime(String time) {
        this.time = time;
    }

    /**
     * 获取所扣分数
     *
     * @return score - 所扣分数
     */
    public Integer getScore() {
        return score;
    }

    /**
     * 设置所扣分数
     *
     * @param score 所扣分数
     */
    public void setScore(Integer score) {
        this.score = score;
    }

    /**
     * 获取违章简介
     *
     * @return remarks - 违章简介
     */
    public String getRemarks() {
        return remarks;
    }

    /**
     * 设置违章简介
     *
     * @param remarks 违章简介
     */
    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
}