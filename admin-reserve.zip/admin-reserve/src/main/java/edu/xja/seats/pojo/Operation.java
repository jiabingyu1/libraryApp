package edu.xja.seats.pojo;

import javax.persistence.*;

@Table(name = "`operation`")
public class Operation {
    /**
     * 具体的方法
     */
    @Id
    @Column(name = "operationId")
    @GeneratedValue(generator = "JDBC")
    private Integer operationid;

    /**
     * 方法名
     */
    @Column(name = "operationName")
    private String operationname;

    /**
     * 所属菜单
     */
    @Column(name = "menuId")
    private Integer menuid;

    @Column(name = "menuName")
    private String menuname;

    /**
     * 获取具体的方法
     *
     * @return operationId - 具体的方法
     */
    public Integer getOperationid() {
        return operationid;
    }

    /**
     * 设置具体的方法
     *
     * @param operationid 具体的方法
     */
    public void setOperationid(Integer operationid) {
        this.operationid = operationid;
    }

    /**
     * 获取方法名
     *
     * @return operationName - 方法名
     */
    public String getOperationname() {
        return operationname;
    }

    /**
     * 设置方法名
     *
     * @param operationname 方法名
     */
    public void setOperationname(String operationname) {
        this.operationname = operationname;
    }

    /**
     * 获取所属菜单
     *
     * @return menuId - 所属菜单
     */
    public Integer getMenuid() {
        return menuid;
    }

    /**
     * 设置所属菜单
     *
     * @param menuid 所属菜单
     */
    public void setMenuid(Integer menuid) {
        this.menuid = menuid;
    }

    /**
     * @return menuName
     */
    public String getMenuname() {
        return menuname;
    }

    /**
     * @param menuname
     */
    public void setMenuname(String menuname) {
        this.menuname = menuname;
    }
}