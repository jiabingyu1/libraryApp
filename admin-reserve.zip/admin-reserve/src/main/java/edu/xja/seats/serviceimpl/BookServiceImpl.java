package edu.xja.seats.serviceimpl;

import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import edu.xja.seats.dao.BookMapper;
import edu.xja.seats.pojo.Book;
import edu.xja.seats.service.BookService;
@Service
public class BookServiceImpl implements BookService{

    @Resource
    private BookMapper bookMapper;

    @Override
    public int updateBatch(List<Book> list) {
        return bookMapper.updateBatch(list);
    }

    @Override
    public int batchInsert(List<Book> list) {
        return bookMapper.batchInsert(list);
    }

    @Override
    public int insertOrUpdate(Book record) {
        return bookMapper.insertOrUpdate(record);
    }

    @Override
    public int insertOrUpdateSelective(Book record) {
        return bookMapper.insertOrUpdateSelective(record);
    }

}
