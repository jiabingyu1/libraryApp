package edu.xja.seats.service;

import java.util.List;

import edu.xja.seats.pojo.Illegal;

public interface IllegalService {


    int updateBatch(List<Illegal> list);

    int batchInsert(List<Illegal> list);

    int insertOrUpdate(Illegal record);

    int insertOrUpdateSelective(Illegal record);

    List<Illegal> findAllIllegal(Illegal illegal);

    int addIllega(Illegal illegal);

    int deleIllega(Illegal illegal);

    Illegal findOne(Illegal illegal);

    int illegaSet(int choiceId);


}
