package edu.xja.seats.controller;

import edu.xja.seats.pojo.User;
import edu.xja.seats.common.response.Result;
import edu.xja.seats.service.RoleService;
import edu.xja.seats.service.UserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;



@Api(value = "用户注册管理", tags = "用户注册")
@RestController
public class RegisterController {
    @Autowired
    private UserService userService;
    @Autowired
    private RoleService roleService;

    @ApiOperation(value = "用户注册")
    @GetMapping("/register")
    public Result register(@RequestBody User user) {

//        userService.add(user);
        return Result.success();
    }
}
