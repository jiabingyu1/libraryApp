package edu.xja.seats.controller;

import edu.xja.seats.common.response.QueryResult;
import edu.xja.seats.common.response.ResponseResult;
import edu.xja.seats.pojo.Notice;
import edu.xja.seats.service.NoticeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

@RestController

public class NoticeController {
    @Autowired
    private NoticeService noticeService;

    @Resource
    private QueryResult queryResult;

    @GetMapping("/notice")
    public QueryResult getNotice() {
        List<Notice> list = noticeService.selectNotice();
        queryResult.setList(list);
        return queryResult;
    }
}
