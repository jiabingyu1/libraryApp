package edu.xja.seats.dao;

import edu.xja.seats.pojo.Room;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.Mapper;

public interface RoomMapper extends Mapper<Room> {
    int updateBatch(List<Room> list);

    int batchInsert(@Param("list") List<Room> list);

    int insertOrUpdate(Room record);

    int insertOrUpdateSelective(Room record);
    int  findRoomScore(int typeId);
}