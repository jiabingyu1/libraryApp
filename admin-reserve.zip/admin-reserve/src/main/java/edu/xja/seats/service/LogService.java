package edu.xja.seats.service;

import java.util.List;
import edu.xja.seats.pojo.Log;
public interface LogService{


    int updateBatch(List<Log> list);

    int batchInsert(List<Log> list);

    int insertOrUpdate(Log record);

    int insertOrUpdateSelective(Log record);

}
