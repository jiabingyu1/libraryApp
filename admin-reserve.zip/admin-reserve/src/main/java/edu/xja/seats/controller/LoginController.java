package edu.xja.seats.controller;


import javax.annotation.Resource;
import javax.annotation.Resources;
import javax.naming.Name;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import edu.xja.seats.common.response.QueryResult;
import edu.xja.seats.common.response.ResponseResult;
import edu.xja.seats.service.RoleService;
import edu.xja.seats.service.UserService;
import edu.xja.seats.utils.StringUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import edu.xja.seats.pojo.User;
import org.springframework.web.bind.annotation.RestController;

/**
 * 登录
 */
@Api(value = "用户登录管理", tags = "用户登录")
@RestController
public class LoginController {
    @Autowired
    private UserService userService;
    @Autowired
    private RoleService roleService;
   @Resource(name = "queryResult")
    QueryResult queryResult;

    @ApiOperation(value = "用户登录")
    @GetMapping("login")
    public QueryResult login(User user) {
        try {
            if (StringUtil.isEmpty(user.getUsername()) || StringUtil.isEmpty(user.getPassword())) {
                queryResult.setData(1);
                queryResult.setMsg("账号或密码不能为空");
                return queryResult;
            }
            User user1 = userService.login(user);
            if (StringUtils.isEmpty(user1)) {
                queryResult.setData(1);
                queryResult.setMsg("账号或密码错误");
                return queryResult;
            } else {
                queryResult.setData(user1);
                queryResult.setMsg("登录成功");
                return queryResult;
            }
        } catch (Exception e) {
            e.printStackTrace();
            queryResult.setData("系统出错");
            return queryResult;
        }
    }

    @ApiOperation("/ 更新密码")
    @PostMapping("updatePassword")
    public ResponseResult updatePassword(User user) {
        try {
            userService.insertOrUpdate(user);
            return ResponseResult.SUCCESS();
        } catch (Exception e) {
            return ResponseResult.FAIL();
        }

    }


    //退出
    private void logout(HttpServletRequest request, HttpServletResponse response) throws Exception {

    }

}
