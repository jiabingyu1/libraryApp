package edu.xja.seats.pojo;

import javax.persistence.*;

@Table(name = "score")
public class Score {
    @Id
    @Column(name = "id")
    @GeneratedValue(generator = "JDBC")
    private Integer id;

    @Column(name = "studentno")
    private String studentno;

    @Column(name = "studentname")
    private String studentname;

    @Column(name = "total")
    private Integer total;

    /**
     * @return id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return studentno
     */
    public String getStudentno() {
        return studentno;
    }

    /**
     * @param studentno
     */
    public void setStudentno(String studentno) {
        this.studentno = studentno;
    }

    /**
     * @return studentname
     */
    public String getStudentname() {
        return studentname;
    }

    /**
     * @param studentname
     */
    public void setStudentname(String studentname) {
        this.studentname = studentname;
    }

    /**
     * @return total
     */
    public Integer getTotal() {
        return total;
    }

    /**
     * @param total
     */
    public void setTotal(Integer total) {
        this.total = total;
    }
}