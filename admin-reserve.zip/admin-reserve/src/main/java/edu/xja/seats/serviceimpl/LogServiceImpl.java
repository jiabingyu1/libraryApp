package edu.xja.seats.serviceimpl;

import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import edu.xja.seats.pojo.Log;
import edu.xja.seats.dao.LogMapper;
import edu.xja.seats.service.LogService;
@Service
public class LogServiceImpl implements LogService{

    @Resource
    private LogMapper logMapper;

    @Override
    public int updateBatch(List<Log> list) {
        return logMapper.updateBatch(list);
    }

    @Override
    public int batchInsert(List<Log> list) {
        return logMapper.batchInsert(list);
    }

    @Override
    public int insertOrUpdate(Log record) {
        return logMapper.insertOrUpdate(record);
    }

    @Override
    public int insertOrUpdateSelective(Log record) {
        return logMapper.insertOrUpdateSelective(record);
    }

}
