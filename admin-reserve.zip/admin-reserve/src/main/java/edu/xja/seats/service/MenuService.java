package edu.xja.seats.service;

import java.util.List;
import edu.xja.seats.pojo.Menu;
public interface MenuService{


    int updateBatch(List<Menu> list);

    int batchInsert(List<Menu> list);

    int insertOrUpdate(Menu record);

    int insertOrUpdateSelective(Menu record);

}
