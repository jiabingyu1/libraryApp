package edu.xja.seats.service;

import java.util.List;
import edu.xja.seats.pojo.Notice;
public interface NoticeService{

    List<Notice> selectNotice();

    int updateBatch(List<Notice> list);

    int batchInsert(List<Notice> list);

    int insertOrUpdate(Notice record);

    int insertOrUpdateSelective(Notice record);

}
