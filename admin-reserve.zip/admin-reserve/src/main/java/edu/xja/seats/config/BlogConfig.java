package edu.xja.seats.config;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class BlogConfig {
    @Bean
    TopicExchange BlogExchange(){
        return  new TopicExchange("BlogExchange");
    }
    @Bean
    Queue BlogJava(){
        return  new Queue("BlogJavaQueue",true);
    }
    @Bean
    Queue BlogNet(){
        return  new Queue("BlogNetQueue",true);
    }
    @Bean
    Queue BlogAll(){
        return  new Queue("BlogAll",true);
    }
    @Bean
    Binding BingJava(){
        return  BindingBuilder.bind(BlogJava()).to(BlogExchange()).with("blog.java");
    }
    @Bean
    Binding BingNet(){
        return  BindingBuilder.bind(BlogNet()).to(BlogExchange()).with("blog.net");

    }
    @Bean
    Binding BingAll(){
        return  BindingBuilder.bind(BlogAll()).to(BlogExchange()).with("blog.#");
    }

}
