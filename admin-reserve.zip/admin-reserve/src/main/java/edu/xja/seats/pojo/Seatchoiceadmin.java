package edu.xja.seats.pojo;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

public class Seatchoiceadmin {
    /**
     * 座位选择表
     */
    @Id
    @Column(name = "id")
    @GeneratedValue(generator = "JDBC")
    private Integer id;

    /**
     * 学号
     */
    @Column(name = "studentno")
    private String studentno;

    /**
     * 座位号key
     */
    @Column(name = "seatkeyword")
    private String seatkeyword;

    /**
     * 选择时间
     */
    @Column(name = "`time`")
    private String time;

    /**
     * 状态
     */
    @Column(name = "`status`")
    private String status;

    @Column(name = "`roomid`")
    private Integer roomid;

    @Column(name = "`row`")
    private Integer row;

    @Column(name = "`col`")
    private Integer col;

    public Integer getRoomid() {
        return roomid;
    }

    public void setRoomid(Integer roomid) {
        this.roomid = roomid;
    }

    public Integer getRow() {
        return row;
    }

    public void setRow(Integer row) {
        this.row = row;
    }

    public Integer getCol() {
        return col;
    }

    public void setCol(Integer col) {
        this.col = col;
    }

    /**
     * 获取座位选择表
     *
     * @return id - 座位选择表
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置座位选择表
     *
     * @param id 座位选择表
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取学号
     *
     * @return studentno - 学号
     */
    public String getStudentno() {
        return studentno;
    }

    /**
     * 设置学号
     *
     * @param studentno 学号
     */
    public void setStudentno(String studentno) {
        this.studentno = studentno;
    }

    /**
     * 获取座位号key
     *
     * @return seatkeyword - 座位号key
     */
    public String getSeatkeyword() {
        return seatkeyword;
    }

    /**
     * 设置座位号key
     *
     * @param seatkeyword 座位号key
     */
    public void setSeatkeyword(String seatkeyword) {
        this.seatkeyword = seatkeyword;
    }

    /**
     * 获取选择时间
     *
     * @return time - 选择时间
     */
    public String getTime() {
        return time;
    }

    /**
     * 设置选择时间
     *
     * @param time 选择时间
     */
    public void setTime(String time) {
        this.time = time;
    }

    /**
     * 获取状态
     *
     * @return status - 状态
     */
    public String getStatus() {
        return status;
    }

    /**
     * 设置状态
     *
     * @param status 状态
     */
    public void setStatus(String status) {
        this.status = status;
    }
}
