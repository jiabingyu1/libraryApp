package edu.xja.seats.dao;

import edu.xja.seats.pojo.Teacher;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.Mapper;

public interface TeacherMapper extends Mapper<Teacher> {
    int updateBatch(List<Teacher> list);

    int batchInsert(@Param("list") List<Teacher> list);

    int insertOrUpdate(Teacher record);

    int insertOrUpdateSelective(Teacher record);
}