package edu.xja.seats.utils;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DateTimeUtil extends Date{

    private String date;

    public DateTimeUtil(){
        Calendar calendar = Calendar.getInstance();
        String t = "yyyy-MM-dd HH:mm:ss";
        SimpleDateFormat s = new SimpleDateFormat(t);
        String format = s.format(calendar.getTime());
        date = format;
    }

    @Override
    public String toString() {
        return date;
    }
}
