package edu.xja.seats.service;

import edu.xja.seats.pojo.Role;
import java.util.List;
public interface RoleService{


    int updateBatch(List<Role> list);

    int batchInsert(List<Role> list);

    int insertOrUpdate(Role record);

    int insertOrUpdateSelective(Role record);


}
