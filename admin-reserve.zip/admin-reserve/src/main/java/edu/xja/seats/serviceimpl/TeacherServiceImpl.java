package edu.xja.seats.serviceimpl;

import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import edu.xja.seats.pojo.Teacher;
import edu.xja.seats.dao.TeacherMapper;
import edu.xja.seats.service.TeacherService;
@Service
public class TeacherServiceImpl implements TeacherService{

    @Resource
    private TeacherMapper teacherMapper;

    @Override
    public int updateBatch(List<Teacher> list) {
        return teacherMapper.updateBatch(list);
    }

    @Override
    public int batchInsert(List<Teacher> list) {
        return teacherMapper.batchInsert(list);
    }

    @Override
    public int insertOrUpdate(Teacher record) {
        return teacherMapper.insertOrUpdate(record);
    }

    @Override
    public int insertOrUpdateSelective(Teacher record) {
        return teacherMapper.insertOrUpdateSelective(record);
    }

    @Override
    public Teacher findOneTeacher(Teacher teacher) {
        return teacherMapper.selectOne(teacher);
    }

}
