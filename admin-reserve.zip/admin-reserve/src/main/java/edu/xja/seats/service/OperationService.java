package edu.xja.seats.service;

import java.util.List;
import edu.xja.seats.pojo.Operation;
public interface OperationService{


    int updateBatch(List<Operation> list);

    int batchInsert(List<Operation> list);

    int insertOrUpdate(Operation record);

    int insertOrUpdateSelective(Operation record);

}
