package edu.xja.seats.dao;

import edu.xja.seats.pojo.Choice;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.Mapper;

public interface ChoiceMapper extends Mapper<Choice> {
    int updateBatch(List<Choice> list);

    int batchInsert(@Param("list") List<Choice> list);

    int insertOrUpdate(Choice record);

    int insertOrUpdateSelective(Choice record);
    List<Choice> seleChoice( String time);
    int updateOne(Choice choice);
}