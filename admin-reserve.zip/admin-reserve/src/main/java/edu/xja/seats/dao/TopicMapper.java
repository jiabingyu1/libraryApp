package edu.xja.seats.dao;

import edu.xja.seats.pojo.Topic;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.Mapper;

public interface TopicMapper extends Mapper<Topic> {
    int updateBatch(List<Topic> list);

    int batchInsert(@Param("list") List<Topic> list);

    int insertOrUpdate(Topic record);

    int insertOrUpdateSelective(Topic record);
}