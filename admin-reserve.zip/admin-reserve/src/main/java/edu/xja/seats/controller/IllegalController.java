package edu.xja.seats.controller;

// 学生违规控制器

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import edu.xja.seats.common.response.QueryResult;
import edu.xja.seats.common.response.ResponseResult;
import edu.xja.seats.pojo.Illegal;
import edu.xja.seats.pojo.Score;
import edu.xja.seats.service.IllegalService;
import edu.xja.seats.service.ScoreService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping
@Api(value = "违规管理", tags = "违规管理")
public class IllegalController {


    @Autowired
    private IllegalService illegalService;
    @Autowired
    private ScoreService scoreService;
    @Autowired
    private QueryResult queryResult;

    @ApiOperation("查找用户所有扣分行为")
    @GetMapping("illegalList")
    public QueryResult illegalList(Illegal illegal) {
        try {
            List<Illegal> illegalList = illegalService.findAllIllegal(illegal);
            queryResult.setList(illegalList);
            queryResult.setTotal(illegalList.size());
            queryResult.setData("操作成功");
            return queryResult;
        } catch (Exception e) {
            e.printStackTrace();
            queryResult.setData("系统出错");
            return queryResult;
        }
    }

    @ApiOperation("增加违规")
    @PostMapping("reserveIllegal")
    public ResponseResult reserveIllegal(Illegal illegal) {

        try {
            Score score1 = new Score();
            score1.setStudentno(illegal.getStudentno());
            Score score = scoreService.findOneScore(score1);  //获取socre对象
            int total = score.getTotal();                  //获得原始积分
            int thisScore = illegal.getScore();             //本次扣除积分
            if (thisScore > total) {
                return ResponseResult.FAIL();
            } else {
                illegalService.addIllega(illegal); //加入违章记录
                // 更新分数
                score.setTotal(total - thisScore);
                scoreService.insertOrUpdate(score);
                return ResponseResult.SUCCESS();
            }

        } catch (Exception e) {
            e.printStackTrace();
            return ResponseResult.FAIL();
        }
    }

    @ApiOperation(value = "删除违规")
    @PostMapping("deleteIllegal")
    public ResponseResult delete(Illegal illegal) {
        try {
            Score score1 = new Score();
            score1.setStudentno(illegal.getStudentno());
            Score score = scoreService.findOneScore(score1);
            int total = score.getTotal();                  //获得原始积分
            int thisScore = illegal.getScore();
            score.setTotal(total + thisScore);
            scoreService.insertOrUpdate(score);
            illegalService.deleIllega(illegal);
            return ResponseResult.SUCCESS();
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseResult.FAIL();
        }
    }


}
