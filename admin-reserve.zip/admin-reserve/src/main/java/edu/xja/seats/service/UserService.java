package edu.xja.seats.service;

import java.util.List;

import edu.xja.seats.pojo.User;

public interface UserService {


    int updateBatch(List<User> list);

    int batchInsert(List<User> list);

    int insertOrUpdate(User record);

    int insertOrUpdateSelective(User record);

    User login(User user);

    List<User> seleUserList();

    int   deleUser(User user);

    int usercate(String userid);
}
