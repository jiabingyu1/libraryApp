package edu.xja.seats.dao;

import edu.xja.seats.pojo.Notice;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import tk.mybatis.mapper.common.Mapper;

public interface NoticeMapper extends Mapper<Notice> {
    int updateBatch(List<Notice> list);

    int batchInsert(@Param("list") List<Notice> list);

    int insertOrUpdate(Notice record);

    int insertOrUpdateSelective(Notice record);

    @Select("select * from seat.notice")
    List<Notice> selectNotice();
}