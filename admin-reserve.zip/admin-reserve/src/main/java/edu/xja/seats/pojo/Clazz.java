package edu.xja.seats.pojo;

import javax.persistence.*;

@Table(name = "clazz")
public class Clazz {
    /**
     * 班级主键
     */
    @Id
    @Column(name = "id")
    @GeneratedValue(generator = "JDBC")
    private Integer id;

    /**
     * 所属学院
     */
    @Column(name = "xueyuan")
    private String xueyuan;

    /**
     * 所属专业
     */
    @Column(name = "zhuanye")
    private String zhuanye;

    /**
     * 辅导员，编号
     */
    @Column(name = "teacherno")
    private String teacherno;

    /**
     * 班级名称
     */
    @Column(name = "`name`")
    private String name;

    /**
     * 获取班级主键
     *
     * @return id - 班级主键
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置班级主键
     *
     * @param id 班级主键
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取所属学院
     *
     * @return xueyuan - 所属学院
     */
    public String getXueyuan() {
        return xueyuan;
    }

    /**
     * 设置所属学院
     *
     * @param xueyuan 所属学院
     */
    public void setXueyuan(String xueyuan) {
        this.xueyuan = xueyuan;
    }

    /**
     * 获取所属专业
     *
     * @return zhuanye - 所属专业
     */
    public String getZhuanye() {
        return zhuanye;
    }

    /**
     * 设置所属专业
     *
     * @param zhuanye 所属专业
     */
    public void setZhuanye(String zhuanye) {
        this.zhuanye = zhuanye;
    }

    /**
     * 获取辅导员，编号
     *
     * @return teacherno - 辅导员，编号
     */
    public String getTeacherno() {
        return teacherno;
    }

    /**
     * 设置辅导员，编号
     *
     * @param teacherno 辅导员，编号
     */
    public void setTeacherno(String teacherno) {
        this.teacherno = teacherno;
    }

    /**
     * 获取班级名称
     *
     * @return name - 班级名称
     */
    public String getName() {
        return name;
    }

    /**
     * 设置班级名称
     *
     * @param name 班级名称
     */
    public void setName(String name) {
        this.name = name;
    }
}