package edu.xja.seats.common.response;

public interface Response {
    boolean SUCCESS = true;
    int SUCCESS_CODE = 10000;
}
