package edu.xja.seats.serviceimpl;

import jdk.nashorn.internal.ir.LiteralNode;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import edu.xja.seats.pojo.User;
import edu.xja.seats.dao.UserMapper;
import edu.xja.seats.service.UserService;
@Service
public class UserServiceImpl implements UserService{

    @Resource
    private UserMapper userMapper;

    @Override
    public int updateBatch(List<User> list) {
        return userMapper.updateBatch(list);
    }

    @Override
    public int batchInsert(List<User> list) {
        return userMapper.batchInsert(list);
    }

    @Override
    public int insertOrUpdate(User record) {
        return userMapper.insertOrUpdate(record);
    }

    @Override
    public int insertOrUpdateSelective(User record) {
        return userMapper.insertOrUpdateSelective(record);
    }

    @Override
    public User login(User user) {
        return userMapper.selectOne(user);
    }

    @Override
    public List<User> seleUserList() {
        return userMapper.selectAll();
    }

    @Override
    public int deleUser(User user) {

        return userMapper.delete(user);
    }

    @Override
    public int usercate(String userid) {
        return userMapper.usercate(userid);
    }
}
