package edu.xja.seats.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import edu.xja.seats.common.response.QueryResult;
import edu.xja.seats.common.response.ResponseResult;
import edu.xja.seats.dao.UserMapper;
import edu.xja.seats.pojo.*;
import edu.xja.seats.service.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * 用户管理
 */
@Api(value = "用户管理", tags = "用户管理")
@RestController
public class UserController {
    @Autowired
    private UserService userService;
    @Resource
    private QueryResult queryResult;
    @Autowired
    private TeacherService teacherService;
    @Autowired
    private StudentService studentService;
    @Autowired
    private ClazzService clazzService;
    @Autowired
    private ScoreService scoreService;


    @ApiOperation(value = "查询用户集合")
    @GetMapping("userList")
    public QueryResult userList() {
        try {
            List<User> userList = userService.seleUserList();
            queryResult.setList(userList);
            return queryResult;
        } catch (Exception e) {
            e.printStackTrace();
            queryResult.setData("查询失败");
            return queryResult;
        }

    }

    @ApiOperation(value = "查询用户级别")
    @ResponseBody
    @GetMapping("usercate")
    public Integer usercate(String userid) {
        Integer cate = userService.usercate(userid);
        return cate;
    }


    // 新增或修改
    @ApiOperation(value = "新增或修改")
    @GetMapping("reserveUser")
    public QueryResult reserveUser(User user) {
        User user1 = userService.login(user);
        try {
            if (user1 != null) {
                queryResult.setData("对不起，用户名不能为空");
                return queryResult;
            } else {
                userService.insertOrUpdate(user);
                queryResult.setData("添加成功");
                return queryResult;
            }
        } catch (Exception e) {
            e.printStackTrace();
            queryResult.setData("系统出错");
            return queryResult;
        }
    }


    @GetMapping("deleteUser")
    public ResponseResult delUser(User user) {
        try {
            userService.deleUser(user);
            return ResponseResult.SUCCESS();


        } catch (Exception e) {
            return ResponseResult.FAIL();
        }
    }

    @ApiOperation("查询用户的资料")
    @GetMapping(value = "seleUser")
    public QueryResult seleUser(User user) {
        try {
            if (user.getRoleid() == 2) {
                Teacher teacher = new Teacher();
                teacher.setNo(user.getUsername());
                queryResult.setData(teacherService.findOneTeacher(teacher));
                queryResult.setMsg("查询成功");
                return queryResult;

            } else if (user.getRoleid() == 3) {
                Clazz clazz = new Clazz();
                Student student = new Student();
                Score score = new Score();
                score.setStudentno(user.getUsername());
                student.setNo(user.getUsername());
                clazz.setId(studentService.findOneStudent(student).getClazzid());
                studentService.findOneStudent(student);
                clazzService.findOneClazz(clazz);
                scoreService.findOneScore(score);
                Map<Object, Object> userMap = new HashMap<>();
                userMap.put("username", studentService.findOneStudent(student).getName());
                userMap.put("college", clazzService.findOneClazz(clazz).getXueyuan());
                userMap.put("claszz", clazzService.findOneClazz(clazz).getZhuanye());
                userMap.put("score", scoreService.findOneScore(score).getTotal());
                userMap.put("studenton", user.getUsername());
                queryResult.setData(userMap);
                queryResult.setMsg("查询成功");
                return queryResult;
            } else {
                queryResult.setMsg("我是管理员");
                return queryResult;
            }

        } catch (Exception e) {
            queryResult.setMsg("系统出错");
            return queryResult;
        }

    }

}
