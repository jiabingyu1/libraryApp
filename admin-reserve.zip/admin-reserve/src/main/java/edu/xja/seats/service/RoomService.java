package edu.xja.seats.service;

import java.util.List;

import edu.xja.seats.pojo.Room;

public interface RoomService {


    int updateBatch(List<Room> list);

    int batchInsert(List<Room> list);

    int insertOrUpdate(Room record);

    Room findRoomByRoomId(int roomid);

    List<Room> findRoom(Room room);

    int insertOrUpdateSelective(Room record);

    int findRoomScore(int typeId);

    List<Room> findAll();

    int updateRoom(Room room);

    int addRoom(Room room);
    int deleteRoom (Room room);

}
