package edu.xja.seats.dao;

import edu.xja.seats.pojo.User;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import tk.mybatis.mapper.common.Mapper;

public interface UserMapper extends Mapper<User> {
    int updateBatch(List<User> list);

    int batchInsert(@Param("list") List<User> list);

    int insertOrUpdate(User record);

    int insertOrUpdateSelective(User record);

    void add(User user);

    @Select("select roleId from seat.user where username = #{userid}")
    int usercate(String userid);
}