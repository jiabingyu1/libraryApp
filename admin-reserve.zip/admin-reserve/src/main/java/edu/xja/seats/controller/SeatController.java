package edu.xja.seats.controller;
// 座位管理

import java.text.SimpleDateFormat;
import java.util.*;

import javax.annotation.Resource;

import edu.xja.seats.common.response.QueryResult;
import edu.xja.seats.common.response.Result;
import edu.xja.seats.pojo.*;
import edu.xja.seats.service.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

@Api(value = "座位管理", tags = "座位管理")
@RestController
public class SeatController {
    @Resource(name = "queryResult")
    private QueryResult queryResult;
    @Autowired
    private SeatService seatService;
    @Autowired
    private RoomService roomService;
    @Autowired
    private ChoiceService choiceService;
    @Autowired
    private ScoreService scoreService;
    @Autowired
    private IllegalService illegalService;
    @Autowired
    RabbitTemplate rabbitTemplate;


    @ApiOperation(value = "根据条件查找对应的座位list")
    @GetMapping("combolist")
    @ResponseBody
    public QueryResult seatList(Seat seat) {
        List<Seat> list = seatService.findSeat(seat);
        queryResult.setList(list);
        queryResult.setTotal(list.size());
        return queryResult;
    }

    @GetMapping("adminSeatList")
    @ResponseBody
    public QueryResult adminSeatList() {
        List<Seatchoiceadmin> list = seatService.adminSeatList();
        queryResult.setList(list);
        queryResult.setTotal(list.size());
        return queryResult;
    }

    // 今天和明天
    @ApiOperation(value = "获取日期")
    @ResponseBody
    @GetMapping(value = "dateCombo")
    public List<ComboValue> dateCombo() {

        // 获取今明两天时间的String值。格式是yyyy-MM-dd
        Date todayDate = new Date();
        SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String today1 = sdf1.format(todayDate);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String today = sdf.format(todayDate);
        List<ComboValue> list = new ArrayList<ComboValue>();
        ComboValue cv = new ComboValue(today, "今天  " + today);
        list.add(cv);
        ComboValue cv2 = new ComboValue(today1, "moredetail");
        list.add(cv2);
        return list;
    }

    // 获取明天日期
    public static Date getNextDay(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DAY_OF_MONTH, 1);
        date = calendar.getTime();
        return date;
    }


    //查找自己的座位
    @ApiOperation(value = "查找自己的座位")
    @GetMapping("myselfSeat")
    public QueryResult myselfSeat(User user) {
        try {
            Date todayDate = new Date();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String today = sdf.format(todayDate);
            Choice choice = new Choice();
            choice.setStudentno(user.getUsername());
            List<Choice> choiceList = choiceService.findOneChoice(choice);
            Seat seat = new Seat();
            seat.setStudentno(user.getUsername());
            List<Map> mapList = new ArrayList<>();
            for (int i = 0; i < choiceList.size(); i++) {
                Map<Object, Object> map = new HashMap<>();
                String str = choiceList.get(i).getSeatkeyword().substring(17, choiceList.get(i).getSeatkeyword().length());
                map.put("seatName", str);
                map.put("startTime", choiceList.get(i).getTime());
                String endtime= choiceList.get(i).getTime().substring(0,10);
                map.put("endTime", endtime + " 23:00:00");
                map.put("status", choiceList.get(i).getStatus());
                map.put("choiceId", choiceList.get(i).getId());
                if (choiceList.get(i).getStatus().equals("1")) {
                    map.put("signTime", choiceList.get(i).getTime());
                } else {
                    map.put("signTime", "未签到");
                }
                if (choiceList.get(i).getStatus().equals("6")) {
                    Illegal illegal = new Illegal();
                    illegal.setChoiceId(choiceList.get(i).getId());
                    map.put("illegal", illegalService.findOne(illegal).getRemarks());
                } else {
                    map.put("illegal", "none");
                }
                mapList.add(map);
            }
            Collections.reverse(mapList);
            queryResult.setList(mapList);
            queryResult.setTotal(mapList.size());
            queryResult.setMsg("查询成功");
            return queryResult;

        } catch (Exception e) {
            e.printStackTrace();
            queryResult.setMsg("系统出错");
            return queryResult;
        }
    }


    // 保存选中座位
    @ApiOperation(value = "保存选中座位")
    @PostMapping("saveSeat")
    public QueryResult saveSeat(User user, Integer roomId, Integer seatId) {
        try {
            String studentno = user.getUsername();
            Score score = new Score();
            score.setStudentno(studentno);
            score = scoreService.findOneScore(score);
            int myScore = score.getTotal(); //该学生分数
            int type = roomService.findRoomByRoomId(roomId).getTypeid();
            int needScore = roomService.findRoomScore(type);
            Seat seat0 = new Seat();
            seat0.setStudentno(user.getUsername());
            Seat seatTest = seatService.findOneSeat(seat0);
            Seat seat = new Seat();
            seat.setId(seatId);
            Seat seat1 = seatService.findOneSeat(seat);
            if (user.getRoleid() == 1 || user.getRoleid() == 2) {  //超管和教师不能选座
                queryResult.setMsg("对不起，该阅览室选座只对学生开放");
                return queryResult;
            } else if (needScore >= myScore) {
                queryResult.setData(1);
                queryResult.setMsg("预约失败！您的信用积分不允许在该阅览室选座");
                return queryResult;
            } else if (!StringUtils.isEmpty(seatTest)) {
                queryResult.setData(1);
                queryResult.setMsg("预约失败！您已有预约");
                return queryResult;
            } else if (!seatService.findOneSeat(seat).getStudentno().equals("1")) {
                queryResult.setData(1);
                queryResult.setMsg("已有座位预约，请选择其他座位");
                return queryResult;
            } else {
                Date todayDate = new Date();
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                String today = sdf.format(todayDate);
                // 无预约 OK的
                String keyword = seat1.getKeyword();
                Choice choice = new Choice();
                choice.setSeatkeyword(keyword);
                choice.setStudentno(studentno);
                choice.setTime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
                choice.setStatus("0");
                choiceService.insertOrUpdate(choice);
                choice.setId(choice.getId());
                seat1.setStudentno(studentno);
                seatService.updateSeat(seat1);
                rabbitTemplate.convertAndSend("SeatExchange", "SeatKey", choice);
                queryResult.setMsg("预约成功");
                return queryResult;
            }
        } catch (Exception e) {
            e.printStackTrace();
            queryResult.setMsg("系统出错");
            return queryResult;
        }

    }

    @ApiOperation(value = "取消预约座位")
    @PostMapping("cancelSeat")
    public QueryResult cancelSeat(User user, int choiceId) {
        try {
            List<ComboValue> comboValues = dateCombo();
            String time = String.valueOf(comboValues.get(1).getValue());
            Choice choice = choiceService.findOneByPrimKey(choiceId);
            choice.setStatus("5");
            choice.setTime(time);
            choiceService.updateOne(choice);
            seatService.cancelSeat(user.getUsername());
            queryResult.setMsg("取消成功");
            return queryResult;
        } catch (Exception e) {
            e.printStackTrace();
            queryResult.setMsg("系统出错");
            return queryResult;
        }
    }

    @ApiOperation("签到有关操作")
    @GetMapping(value = "singin")
    public QueryResult seatSingIn(int choiceId) {
        try {
            List<ComboValue> comboValues = dateCombo();
            String time = String.valueOf(comboValues.get(1).getValue());
            Choice choice = choiceService.findOneByPrimKey(choiceId);
            choice.setStatus("1");
            choice.setTime(time);
            choiceService.updateOne(choice);
            queryResult.setMsg("签到 成功");
            return queryResult;
        } catch (Exception e) {
            queryResult.setMsg("系统出错");
            return queryResult;
        }
    }

    @ApiOperation(value = "暂时离开")
    @PostMapping(value = "leaveSeat")
    public QueryResult leaveSeat(int choiceId) {
        try {
            List<ComboValue> comboValues = dateCombo();
            String time = String.valueOf(comboValues.get(1).getValue());
            Choice choice = choiceService.findOneByPrimKey(choiceId);
            choice.setTime(time);
            choice.setStatus("2");
            choiceService.updateOne(choice);
            rabbitTemplate.convertAndSend("SeatExchange", "SeatKey", choice);
            queryResult.setMsg("操作成功");
            return queryResult;
        } catch (Exception e) {
            queryResult.setMsg("系统出错");
            return queryResult;
        }

    }

    @ApiOperation(value = "重新返回")
    @PostMapping(value = "returnSeat")
    public QueryResult returnSeat(int choiceId) {
        try {
            List<ComboValue> comboValues = dateCombo();
            String time = String.valueOf(comboValues.get(1).getValue());
            Choice choice = choiceService.findOneByPrimKey(choiceId);
            choice.setTime(time);
            choice.setStatus("3");
            choiceService.updateOne(choice);
            queryResult.setMsg("操作成功");
            return queryResult;
        } catch (Exception e) {
            queryResult.setMsg("系统出错");
            return queryResult;
        }
    }


    @ApiOperation(value = "释放所有座位资源")
    @PostMapping(value = "deleAllseats")
    public Result deleAllseats() {
        seatService.deleAllseats();
        return Result.success();
    }
}


