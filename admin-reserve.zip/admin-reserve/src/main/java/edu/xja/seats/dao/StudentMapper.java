package edu.xja.seats.dao;

import edu.xja.seats.pojo.Student;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.Mapper;

public interface StudentMapper extends Mapper<Student> {
    int updateBatch(List<Student> list);

    int batchInsert(@Param("list") List<Student> list);

    int insertOrUpdate(Student record);

    int insertOrUpdateSelective(Student record);
}