"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RED = '#ee0a24';
exports.BLUE = '#1989fa';
exports.WHITE = '#fff';
exports.GREEN = '#07c160';
exports.ORANGE = '#ff976a';
exports.GRAY = '#323233';
exports.GRAY_DARK = '#969799';
