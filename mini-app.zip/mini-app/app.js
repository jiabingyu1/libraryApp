//app.js
App({
  onLaunch: function () {
    // 展示本地存储能力
    var logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)

    // 登录
    wx.login({
      success: res => {
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
      }
    })
    // 获取用户信息
    wx.getSetting({
      success: res => {
        if (res.authSetting['scope.userInfo']) {
          // 已经授权，可以直接调用 getUserInfo 获取头像昵称，不会弹框
          wx.getUserInfo({
            success: res => {
              // 可以将 res 发送给后台解码出 unionId
              this.globalData.userInfo = res.userInfo

              // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
              // 所以此处加入 callback 以防止这种情况
              if (this.userInfoReadyCallback) {
                this.userInfoReadyCallback(res)
              }
            }
          })
        }
      }
    })
    var a = this, o = {
      iPhone: 64,
      android: 68,
      iPhoneX: 88
    };
    wx.getSystemInfo({
      success: function (t) {
        var i = o.android;
        -1 !== t.model.indexOf("iPhone X") ? i = o.iPhoneX : -1 !== t.model.indexOf("iPhone") && (i = o.iPhone),
          a.globalData.statusBarHeight = t.statusBarHeight, a.globalData.titleBarHeight = i - t.statusBarHeight;
      },
      failure: function () {
        a.globalData.statusBarHeight = 0, a.globalData.titleBarHeight = 0;
      }
    })
  },
  globalData: {
    userInfo:[]

  }

})