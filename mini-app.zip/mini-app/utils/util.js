var myRquest = function (url, method, fn) {
  wx.showLoading({
    title: '正在加载数据...'
  })

  wx.request({
    url: url,
    method: method || 'GET',
    success: info => {
      wx.hideLoading()
      fn(info)
    }
  })
}

export default myRquest
