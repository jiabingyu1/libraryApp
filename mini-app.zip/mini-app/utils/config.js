  var domain = "http://127.0.0.1"; //统一接口域名，测试环境
// 127.0.0.1   47.94.144.181
exports.domain = domain;