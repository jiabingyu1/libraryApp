var a = [], e = null, t = null, r = null;

function c(a) {
    if (a && a.length > 0) {
        !function(a) {
            if (!a || 0 == a.length) return;
            var e = wx.getStorageSync("wxSearchHisKeys");
            e ? (e.indexOf(a) < 0 && e.unshift(a), wx.setStorage({
                key: "wxSearchHisKeys",
                data: e,
                success: function() {
                    s();
                }
            })) : ((e = []).push(a), wx.setStorage({
                key: "wxSearchHisKeys",
                data: e,
                success: function() {
                    s();
                }
            }));
        }(a);
        var t = r.data.wxSearchData;
        t.value = a, r.setData({
            wxSearchData: t
        }), e(a);
    }
}

function s() {
    var a = [];
    try {
        if (a = wx.getStorageSync("wxSearchHisKeys")) {
            var e = r.data.wxSearchData;
            e.his = a, r.setData({
                wxSearchData: e
            });
        }
    } catch (a) {}
}

module.exports = {
    init: function(c, n, i, h, u) {
        r = c, a = i, e = h, t = u;
        var w = {}, x = {
            barHeight: 43
        };
        w.hotKeys = n, wx.getSystemInfo({
            success: function(a) {
                var e = a.windowHeight;
                x.seachHeight = e - 43, w.view = x, r.setData({
                    wxSearchData: w
                });
            }
        }), s();
    },
    wxSearchInput: function(e) {
        var t = e.detail.value, c = r.data.wxSearchData, s = [];
        if (t && t.length > 0) for (var n = 0; n < a.length; n++) {
            var i = a[n];
            -1 != i.indexOf(t) && s.push(i);
        }
        c.value = t, c.tipKeys = s, r.setData({
            wxSearchData: c
        });
    },
    wxSearchKeyTap: function(a) {
        c(a.target.dataset.key);
    },
    wxSearchDeleteAll: function() {
        wx.removeStorage({
            key: "wxSearchHisKeys",
            success: function(a) {
                var e = r.data.wxSearchData;
                e.his = [], r.setData({
                    wxSearchData: e
                });
            }
        });
    },
    wxSearchConfirm: function(a) {
        "back" == a.target.dataset.key ? t() : c(r.data.wxSearchData.value);
    },
    wxSearchClear: function() {
        var a = r.data.wxSearchData;
        a.value = "", a.tipKeys = [], r.setData({
            wxSearchData: a
        });
    }
};