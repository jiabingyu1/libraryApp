var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../@babel/runtime/helpers/typeof")), r = e(require("../../@babel/runtime/helpers/defineProperty"));

function o(e, t) {
    var r = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(e);
        t && (o = o.filter(function(t) {
            return Object.getOwnPropertyDescriptor(e, t).enumerable;
        })), r.push.apply(r, o);
    }
    return r;
}

function a(e) {
    var r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
    return "object" === (0, t.default)(e) ? e : {
        title: e,
        timeout: r
    };
}

module.exports = {
    showZanToast: function(e, t) {
        var r = this, o = a(e, t), i = (this.data.zanToast || {}).timer;
        clearTimeout(void 0 === i ? 0 : i);
        var n = {
            show: !0,
            icon: o.icon,
            image: o.image,
            title: o.title
        };
        if (this.setData({
            zanToast: n
        }), !(t < 0)) {
            var s = setTimeout(function() {
                r.clearZanToast();
            }, t || 3e3);
            this.setData({
                "zanToast.timer": s
            });
        }
    },
    clearZanToast: function() {
        var e = (this.data.zanToast || {}).timer;
        clearTimeout(void 0 === e ? 0 : e), this.setData({
            "zanToast.show": !1
        });
    },
    showZanLoading: function(e) {
        var t = a(e);
        this.showZanToast(function(e) {
            for (var t = 1; t < arguments.length; t++) {
                var a = null != arguments[t] ? arguments[t] : {};
                t % 2 ? o(a, !0).forEach(function(t) {
                    (0, r.default)(e, t, a[t]);
                }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(a)) : o(a).forEach(function(t) {
                    Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(a, t));
                });
            }
            return e;
        }({}, t, {
            icon: "loading"
        }));
    }
};