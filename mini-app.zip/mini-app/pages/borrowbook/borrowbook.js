// pages/borrowbook/borrowbook.js
var app = getApp();
var config = require("../../utils/config");

Page({

  /**
   * 页面的初始数据
   */
  data: {
    currentName:'正在借阅',
    classify: ["正在借阅", "马上到期","已归还","已到期"],
    bookList:[],
    winH:0,
  },
  changeTab: function (a) {
     this.setData({
      currentName: a.detail.name
    })
    if (a.detail.name =="正在借阅"){
           this.getBookList(0)
    }
    else if (a.detail.name == "马上到期") {
      this.getBookList(4)
    } else if (a.detail.name == "已归还"){
      this.getBookList(1)
    } else if (a.detail.name == "已到期"){
      this.getBookList(2)
    }
  },
  getBookList:function(e){
    wx.request({
      url: config.domain+':8070/borrowSearch?status=' +e+ '&userno=' + app.globalData.userInfo.username,
      method:'get',
      success:info=>{
        this.setData({
            bookList:info.data.list
        })
      }
    })
  },
  returnBook:function(e){
    console.log(e)
    wx.request({
      url: 'http://localhost:8070/updaBorrowStatus?borrowId=' + e.currentTarget.dataset.id+'&status=1',
      method:"post",
        success: info => {
          this.onLoad(0)
      }
    })
  },
  returnBook4: function (e) {
    console.log(e)
    wx.request({
      url: 'http://localhost:8070/updaBorrowStatus?borrowId=' + e.currentTarget.dataset.id + '&status=1',
      method: "post",
      success: info => {
        this.onLoad(4)
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      winH: wx.getSystemInfoSync().windowHeight,
    }),
      this.getBookList(0)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})