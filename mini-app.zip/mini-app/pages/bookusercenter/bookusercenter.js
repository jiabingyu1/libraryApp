// pages/test/test.js
var app = getApp();
var config = require("../../utils/config");

Page({

  /**
   * 页面的初始数据
   */
  data: {
   wxUserInfo:[],
    userInfo: [],
    is_admin:false
  },
  exitsystem:function(){
    wx.navigateTo({
      url: '/pages/login/login',
    })
  },
  goToBorrow:function(){
    wx.navigateTo({
      url: '/pages/borrowbook/borrowbook',
   
    })
  },
  accountManage:function() {
    wx.navigateTo({
      url: '/pages/adminManage/adminManage',
    })
  },

  getUser: function () {
    console.log(app.globalData.userInfo)
    wx.request({
      url: config.domain+':8090/seats/seleUser?roleid=' + app.globalData.userInfo.roleid + '&username=' + app.globalData.userInfo.username,
      method: 'get',
      success: info => {
        this.setData({
          userInfo: info.data.data
        })       
      }
    })
  },
  getCateId: function () {
    wx.request({
      url: config.domain+':8090/seats/usercate?userid='+app.globalData.userInfo.username,
      method:'GET',
      success:info => {
        console.log(info.data)
        if(info.data==1) {
          this.setData({
            is_admin: true
          })
        }
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getUser();
    this.getCateId();
    wx.getStorage({
      key: 'userInfo',
      success: info =>{
        // console.log(info.data)
         this.setData({
           wxUserInfo: info.data
         })
      },
    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})