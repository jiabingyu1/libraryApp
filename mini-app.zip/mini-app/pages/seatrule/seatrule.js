// pages/seatrule/seatrule.js
//const { data } = require("jquery");
//const { GET_MAIN_CANVAS } = require("XrFrame/kanata/lib/backend/native/worker");
var config = require("../../utils/config");

Page({

  /**
   * 页面的初始数据
   */
  data: {
    notice:[]
  },

  getNotice:function() {
    wx.request({
      url: config.domain+':8090/seats/notice',
      method:'GET',
      success:info => {
        console.log(info.data)
        this.setData({
          notice: info.data.list[0]
        })
      }
    })

  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getNotice();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})