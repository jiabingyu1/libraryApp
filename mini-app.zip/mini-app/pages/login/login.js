var app = getApp();
import Toast from '../../assets/vant/toast/toast';
var config = require("../../utils/config");

Page({
  /**
   * 页面的初始数据
   */
  data: {
    userName: [],
    passWord: [],
    userinfo: [],
    msg: []
  },
  userNameEvent: function (e) {
    this.setData({
      userName: e.detail.value
    });
  },
  passwordEvent: function (e) {
    this.setData({
      passWord: e.detail.value
    });
  },
  
  formSubmit: function() {
      wx.showLoading({
        title: "加载中",
      });
  
    wx.request({
      url: config.domain+':8090/seats/login?password='+this.data.passWord+'&username='+this.data.userName,
      method:'get',
      success: info => {
        // console.log(info.data.data)
        // console.log(info.data.total)
        if (info.data.data!=1) {
          app.globalData.userInfo = info.data.data
          this.setData({
            userinfo: info.data.data,
            msg: info.data.msg
          })
          wx.showToast({
            title: '登录成功',
            icon: 'none',
          })
        wx.switchTab({
          url: '/pages/main/main',
        })
        } else {
          wx.showToast({
            title: info.data.msg,
            icon: 'none',
          })

        }
        // console.log(app.globalData.userInfo)
     
      }
    })


  },
    
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) { },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () { },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () { },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () { },
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () { },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () { },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () { },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () { }
})
