// pages/audiobook/cates/cates.js
import myRequest from '../../../utils/util'
var config = require("../../../utils/config");


Page({

  /**
   * 页面的初始数据
   */
  data: {
    readbook: [],
    activeKey: 0,
    wh: 300,
  },
  getAudioBook: function () {
    myRequest(config.domain+":8070/searchRead?keyword=%E8%AF%97", "GET", (info) => {
      info.data.list.forEach(item => {
        item.bookname = item.bookname.substr(0, 4)
      })
      this.setData({
        readbook: info.data.list
      })
    })
  },
  goBookDetail: function (e) {
    console.log("inininin")
    wx.navigateTo({
      url: '/pages/readbook/bookdetail/bookdetail?readbookId=' + this.data.readbook[e.currentTarget.dataset.id].bookno
    })

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getAudioBook()
    this.setData({
      wh: wx.getSystemInfoSync().windowHeight
    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})