// pages/audiobook/audiodetail/audiodetail.js
var app = getApp();
import Notify from '../../../assets/vant/notify/notify';
var config = require("../../../utils/config");
Page({

  /**
   * 页面的初始数据
   */
  data: {
    readbook: [],
    msg:[],
    collection_status:false,
    borrowstatus:false
  },

  getReadBook(e){
    var t = this;
    wx.request({
      url: config.domain+':8070/searchRead?bookNo='+e,
      method:'get',
      success: info => {
        // console.log(info.data.list[0])
        t.setData({
          readbook: info.data.list[0]
        }),
        console.log(this.data.readbook.bookno)
      }
    })
  },

  goBookContent:function(){
    wx.navigateTo({
       url: '/pages/readbook/bookcontent/bookcontent?bookno='+this.data.readbook.bookno,
      })
  },

  borrow: function () {
    wx.request({
      url: config.domain+':8070/insertBorrowBook',
      // + this.data.readbook.bookno + '&status=0&userno=' + app.globalData.userInfo.username  ?bookno=
      data: {
        bookno: this.data.readbook.bookno,
        status: 0,
        userno: app.globalData.userInfo.username
      },
      method: 'post',
      header: {
        "content-type": "application/x-www-form-urlencoded"
      },
      success: info => {
        if (info.data.total == 0) {
          Notify({
            type: 'success',
            message: info.data.msg
          });
          this.setData({
            msg: info.data.msg,
            borrowstatus: true
          })
        } else {
          Notify({
            type: 'danger',
            message: info.data.msg
          });
          this.setData({
            msg: info.data.msg
          })
        }
      }
    })
  },
  borrowstatus: function (e) {
    wx.request({
      url: config.domain+':8070/borrowSearch?bookno=' + e + '&status=0&userno=' + app.globalData.userInfo.username, 
      method: 'get',
      success: info => {
        if (info.data.total > 0) {
          this.setData({
            borrowstatus: true
          })
        }
      }

    })
  },

  collection:function(){
    wx.request({
      url : config.domain+':8070/insertBookshelf',
      method: "POST",
      data: {
        bookcate: 1,
        bookid: this.data.readbook.bookno,
        status: 0,
        usrno: app.globalData.userInfo.username
      },
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      success:info => {
        console.log(info.data.data)
        if(info.data.data==0){
         Notify({
           type: 'success',
           message: info.data.msg
         });
         this.setData({
           msg: info.data.msg,
          collection_status:true
         })
       }else{
         Notify({
           type: 'danger',
           message: info.data.msg
         });
         this.setData({
           msg: info.data.msg
         })
       }
       this.onShow()
      },

  //  wx.request({
  //    url: config.domain+':8070/insertBookshelf?bookcate=1&bookid=' + this.data.readbook.bookno + '&status=0&usrno=' + app.globalData.userInfo.username,
  //    method:'post',
  //    success:info=>{
  //      if(info.data.data==0){
  //        Notify({
  //          type: 'success',
  //          message: info.data.msg
  //        });
  //        this.setData({
  //          msg: info.data.msg,
  //         collection_status:true
  //        })
  //      }else{
  //        Notify({
  //          type: 'danger',
  //          message: info.data.msg
  //        });
  //        this.setData({
  //          msg: info.data.msg
  //        })
  //      }
  //    }
   })
  },
 bookStatus:function(e){
   wx.request({
     url: config.domain+':8070/searchBookshelf?bookcate=1&bookid=' + e + '&usrno=' + app.globalData.userInfo.username,
     method:'get',
     success:info=>{
         if(info.data.total>0){
           this.setData({
             collection_status:true
           })
         }
     }
     
        })
 },

  
  onLoad: function (options) {
    console.log(options)
     this.getReadBook(options.readbookId)
    this.bookStatus(options.readbookId)
    this.borrowstatus(options.readbookId)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})