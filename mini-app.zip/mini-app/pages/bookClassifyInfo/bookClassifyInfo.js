// pages/main/main.js
var n = getApp();
import Dialog from '../../assets/vant/dialog/dialog';
var config = require("../../utils/config");

Page({

  /**
   * 页面的初始数据
   */
  data: {
    currentTab: 0,
    audioCurrent: 0,
    videoList: [],
    bookList: [],
    bookrankArr: [],
    bookPageArr: [],
    classifyId: [],
    duration: .5,
    winH: 0,
    pageNum: 0,
    pagesize: 10,
    marginTop: null,
    currentLibraryIndex: 0,
    currentLibraryId: null,
    isOver: !0,
    currentSite: null,
    pageNumber: 1,
    listType: "local",
    locationShow: !0

  },
  toyuyueLink:function(){
    wx.navigateTo({
      url: '/pages/index/index',
    })
  },

  

/******************图书分类并获取资源******************* */
  // getBookClassifyList: function (f) {
  //   var t = this;
  //   wx.request({
  //     url: config.domain+":8070/homeCateOne?catId="+f,
  //     success: function (a) {
  //       var e = [];
  //       e = a.data.data.length > 6 ? a.data.data.slice(0, 6) : a.data.data;
  //       t.setData({
  //         bookPageArr: e
  //       })
  //     },
  //     fail: function (t) { }
  //   });
  // },
  getBookClassifyList: function (f) {
    var t = this;
    wx.request({
      url: config.domain+":8070/homeCateOne?catId="+f,
      success:info=> {
        var e = [];
        e = info.data.data.length > 6 ? info.data.data.slice(0, 6) : info.data.data;
        console.log(e[0]),
        t.setData({
          bookPageArr: e
        })
      }
    });
  },

  loadIndex: function () {
     this.setData({
      winH: wx.getSystemInfoSync().windowHeight
    }), this.data.winH < 700 ? this.setData({
      marginTop: 35
    }) : this.setData({
      marginTop: 55
    });
  },
  alert1: function () {
    wx.request({
      url: config.domain+':8070/borrowSearch?status=4&userno=' + n.globalData.userInfo.username,
      method:"get",
      success: info => {
 
      }
    })
   

  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log("接收参数为：",options);
    console.log(this.bookPageArr);
    this.loadIndex();
    this.getBookClassifyList(options.classifyId);
    this.alert1();

  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.alert1()

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})