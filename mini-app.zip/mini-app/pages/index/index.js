var app = getApp();
var config = require("../../utils/config");

Page({
  data: {
    imgs: ["https://www.zzuli.edu.cn/_upload/article/images/51/49/f14ace1f49f9bb57c9af38b75c27/692776c8-9757-4766-ac22-18b7b2fdf1d8.jpg","https://x0.ifengimg.com/ucms/2023_45/081B5714FA6F6A7C3206860072011BD1C99F899E_size6497_w4032_h3024.jpg", "../../images/1.jpg"],
    seatId: "",
    lib_la: 22.971277,
    lib_lo: 113.754697,
    is_worker:false,
    account: ""
  },

  checkuser:function() {
    wx.request({
      url: config.domain+':8090/seats/usercate?userid='+app.globalData.userInfo.username,
      method:'GET',
      success:info=>{
        // console.log(info.data)
        if(info.data==2) {
          this.setData({
            is_worker:true
          })
        }
      }
    })
  },

  goroomlist:function(){
    wx.navigateTo({
      url: '/pages/roomlist/roomlist',
    })
  },
  goPersonal: function () {
    wx.navigateTo({
      url: '/pages/personal/personal',
    })
  },
  gorule:function(){
    wx.navigateTo({
      url: '/pages/seatrule/seatrule',
    })
  },
  seat_admin:function() {
    wx.navigateTo({
      url: '/pages/seatadmin/seatadmin',
    })
  },
  onLoad: function (options) {
    this.checkuser();
  },


  onShareAppMessage: function () { }
});