// pages/bookshelf/bookshelf.js
var app = getApp();
import Notify from '../../assets/vant/notify/notify';
var config = require("../../utils/config");


Page({

  /**
   * 页面的初始数据
   */
  data: {
    winH: 0,
    currentName: "图书",
    classify: ["图书", "听书"],
    rackArr: [],
    islongpress: !1,
    statusArr: [],
    pageNum: 1,
    ids: [],
    isOver: !1,
    isshowallcheck: !1,
    ischeckall: !1,
    lecture_sign: "Y7chE6j&jd#g*GMdjM"

  },
  deletebook: function (a) {
    var e = this;
    this.data.ids.length <= 0? Notify({
      type: 'danger',
      message: "请选择"
    }):wx.showModal({
      title: "是否要删除选中的内容？",
      showCancel: !0,
      cancelText: "取消",
      confirmText: "删除",
      success: function (a) {
         console.log(e.data.ids.length)
        for(var i=0; i<e.data.ids.length; i++){
          e.dele(e.data.ids[i])
          console.log(e.data.ids[i])
        }
        e.setData({
          pageNum: 1,
          rackArr: [],
          ids: [],
          statusArr: [],
          isshowallcheck: !1,
          ischeckall: !1
        }), 
        e.getclassifylist(e.data.currentName);
      }
    }),
    this.onLoad()
  },

  getclassifylist: function (a) {
    // console.log(a);
    console.log("图书" == a ? 'true' : 'false');
    var t = this;
    wx.showLoading({
      title: "正在加载"
    }), 
      "图书" == a ? (t.getrackarr(1), wx.hideLoading()) : "听书" == a && (this.getrackarr(2), wx.hideLoading());
  },

  getrackarr:function(a){
    wx.request({
      url: config.domain+':8070/searchBookshelf?usrno=' + app.globalData.userInfo.username,
      method:'get',
      success: info=> {
        if(a==1){
         this.setData({
           rackArr: info.data.data["图书"]
         })
        }else{
          this.setData({
            rackArr: info.data.data["听书"]
          })
        }
      }
    })
  },

  dele:function(e){
    wx.request({
      url: config.domain+':8070/deleBookshelf?bookid=' + e + '&usrno=' + app.globalData.userInfo.username,
      method:'POST',
      success:info=>{
        console.log("删除成功"),
        this.onload();
      }
    })
  },
  checkAllBook: function () {
    var a = this;
    0 == this.data.ischeckall ? (this.data.statusArr.forEach(function (t, e) {
      a.data.statusArr[e] = !0;
    }), this.data.rackArr.forEach(function (t, e) {
      a.data.ids.push(t.bookno);
    }), this.setData({
      ids: this.data.ids
    })) : (this.data.statusArr.forEach(function (t, e) {
      a.data.statusArr[e] = !1;
    }), this.setData({
      ids: []
    })), this.setData({
      statusArr: this.data.statusArr,
      ischeckall: !this.data.ischeckall
    });
  },
  canclecheck: function () {
    var a = this;
    this.data.statusArr.forEach(function (t, e) {
      a.data.statusArr[e] = !1;
    }), this.setData({
      isshowallcheck: !1,
      statusArr: this.data.statusArr,
      ids: []
    });
  },
  editrack: function () {
    this.setData({
      isshowallcheck: !0,
      statusArr: this.data.statusArr
    })
  },
  togglechecked: function (a) {
    console.log(a.currentTarget.dataset.idx+"11111111")
    var t = a.currentTarget.dataset.idx;
    if (this.data.statusArr[t] = !this.data.statusArr[t], this.setData({
      statusArr: this.data.statusArr
    }), this.data.statusArr[t]) {
      console.log(!this.data.statusArr[t]);
      var e = this.data.ids.length;
      console.log(e), this.data.ids[e] = a.currentTarget.dataset.id, this.setData({
        ids: this.data.ids
      });
    } else if (console.log("取消当前主键"), this.data.ids.length > 0) {
      for (var s = 0; s < this.data.ids.length; s++) this.data.ids[s] == a.currentTarget.dataset.id && this.data.ids.splice(s, 1);
      this.setData({
        ids: this.data.ids
      });
    }
    console.log(this.data.ids);
  },
  
  changeTab: function (a) {
    console.log(a.detail.name), this.setData({
      pageNum: 1,
      currentName: a.detail.name
    }), 
    this.getClassifyList(a.detail.name);
  },
  getClassifyList: function (a) {
    // console.log(a);
    console.log("图书" == a ? 'true' : 'false');
    var t = this;
    wx.showLoading({
      title: "正在加载"
    }), 
      "图书" == a ? (t.getRackArr(1), wx.hideLoading()) : "听书" == a && (this.getRackArr(2), wx.hideLoading());
  },
  getRackArr:function(a){
    wx.request({
      url: config.domain+':8070/searchBookshelf?usrno=' + app.globalData.userInfo.username,
      method:'get',
      success: info=> {
        if(a==1){
         this.setData({
           rackArr: info.data.data["图书"]
         })
        }else{
          this.setData({
            rackArr: info.data.data["听书"]
          })
        }
        // this.onLoad();
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {


  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getRackArr(1);
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})