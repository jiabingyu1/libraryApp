// pages/adminManage/crud/crud.js
var config = require("../../../utils/config")
Page({

  /**
   * 页面的初始数据
   */
  data: {
    username :[],
    user: [],
    roleid: [],
    passWord: [],
    xueyuan: [],
    type:[],
    roleid:[],
    college:[],
    claszz:[]
  },

  NameEvent: function (e) {
    this.setData({
      userName: e.detail.value
    });
  },

  passwordEvent: function (e) {
    this.setData({
      passWord: e.detail.value
    });
  },

  CollegeEvent:function (e) {
    this.setData ({
      xueyuan: e.detail.value
    })
  },

  ClaszzEvent:function (e) {
    this.setData ({
      xueyuan: e.detail.value
    })
  },

  TypeEvent:function (e) {
    this.setData ({
      type: e.detail.value
    });
    if(type='管理员') this.setData({roleid: 1});
    else if(type='工作人员') this.setData({roleid: 2});
    else if(type='学生') this.setData({roleid: 3});
  },

  formSubmit: function() {
    wx.showLoading({
      title: "加载中",
    });
    wx.request({
      url: config.domain+':8090/seats/reserveUser?name='+this.data.username,
      method: 'GET',
      success:info => {
        console.log("修改成功")
      }
    })
  },

  seleUser: function() {
    wx.request({
      url: config.domain+':8090/seats/seleUser?roleid=' + this.data.roleid + '&username=' + this.data.username,
      method: 'GET',
      success:info => {
        this.setData({
          user: info.data.data
        })
        console.log(this.data.user)
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    //  console.log(options.username);
    this.setData({
      username: options.username,
      roleid: options.roleid
    },() => {
      console.log(this.data.username+this.data.roleid);
      // this.seleUser();
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

    this.seleUser();
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})