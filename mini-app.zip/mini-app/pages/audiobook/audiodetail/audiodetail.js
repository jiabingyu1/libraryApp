// pages/audiobook/audiodetail/audiodetail.js
var app = getApp();
import Notify from '../../../assets/vant/notify/notify';
var config = require("../../../utils/config");
Page({

  /**
   * 页面的初始数据
   */
  data: {
    audiobook:[],
    chapter:[],
    tabidx:0,
    msg: [],
    collection_status: false,
    isshowhb: false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  getChpter:function(e){
    wx.request({
      url:  config.domain+':8070/findAudioChapter?bookId=' + e,
      method:'get',
      success: info => {
          this.setData({
            chapter: info.data.list
          })
      }
    })
  },
  changeTab :function(t) {
    console.log(t.currentTarget.dataset.idx), 
    this.setData({
      tabidx: t.currentTarget.dataset.idx
    });

  },
  checkCxid: function (t) {
    var a = t.currentTarget.dataset;
    wx.request({
      url: config.domain+':8070/findAudioUrl?chapterId=' + a.chapterid,
      method:'get',
      success: info => {
          wx.navigateTo({
            url: "/pages/audiobook/audiourl/audiourl?bookId=" + this.data.audiobook.id + "&chapterId=" + a.chapterid+"&prv="+0 + "&title=" + a.title +  "&bookno=" + this.data.audiobook.bookno+ "&name=" + a.name + "&cover=" + a.cover + "&time=" + info.data.list[0].chapterDuration + "&url=" + info.data.data.audioUrl
        })
      }
    })
  },
  goplay: function (e) {
    var a = e.currentTarget.dataset.id;
    wx.request({
      url: config.domain+':8070/findAudioUrl?chapterId=' + this.data.chapter[a].chapterId,
      method: 'get',
      success: info => {
        wx.navigateTo({
          url: "/pages/audiobook/audiourl/audiourl?bookId=" + this.data.audiobook.id + "&chapterId=" + this.data.chapter[a].chapterId + "&bookno=" + this.data.audiobook.bookno + "&prv="+a+"&title=" + this.data.chapter[a].chapterTitle + "&name=" + this.data.audiobook.bookname + "&cover=" + this.data.audiobook.coverHttps + "&time=" + info.data.list[a].chapterDuration + "&url=" + info.data.data.audioUrl 
        })
      }
    })


  },
  getAudiobook:function(e){
     wx.request({
       url: config.domain+':8070/searchAudio?bookNo='+e,
       method: 'get',
       success: info => {
         this.setData({
           audiobook:info.data.list[0]

         })
       }
     })

  },
  collection: function () {
    wx.request({
      url: config.domain+':8070/insertBookshelf?bookcate=2&bookid=' + this.data.audiobook.bookno + '&status=0&usrno=' + app.globalData.userInfo.username,
      method: 'post',
      success: info => {
        if (info.data.data == 0) {
          Notify({
            type: 'success',
            message: info.data.msg
          });
          this.setData({
            msg: info.data.msg,
            collection_status: true
          })
        } else {
          Notify({
            type: 'danger',
            message: info.data.msg
          });
          this.setData({
            msg: info.data.msg
          })
        }
      }
    })
  },
  bookStatus: function (e) {
    wx.request({
      url: config.domain+':8070/searchBookshelf?bookcate=2&bookid=' + e + '&usrno=' + app.globalData.userInfo.username,
      method: 'get',
      success: info => {
        if (info.data.total > 0) {
          this.setData({
            collection_status: true
          })
        }
      }

    })
  },
    
  madehbBtnFn:function() {
    this.isshowhb=true
  },

  onLoad: function (options) {
    this.getAudiobook(options.audiobookNo),
    this.getChpter(options.audiobookNo),
    this.bookStatus(options.audiobookNo)
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})