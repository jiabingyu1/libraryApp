var t = getApp(),
 e = require("../../../utils/my.js"), 
 a = wx.getBackgroundAudioManager() ;
var config = require("../../../utils/config");


Page({
  data: {
    bookId: '',
    chapterId: '',
    title: '',
    name: "",
    cover: "",
    url: "",
    audios: [],
    isPlay: !1,
    currentTimeStr: "--:--",
    durationStr: "--:--",
    percent: 0,
    bid: null,
    bookno: a.b,
    prv:0,


  },
  onLoad: function (a) {
  this.setData({
      bookId: a.bookId,
      chapterId: a.chapterId,
      title: decodeURIComponent(a.title),
      name: a.name,
      cover: a.cover,
      bid: a.bid,
      url:a.url,
    durationStr: this.timeFormat(a.time),
      bookno:a.bookno,
      prv:a.prv
     }),
   this.initAudioContext()
    this.getAudios(a.bookno)
  },

  onPlayPrevClick:function(){
   var prv1=this.data.prv;
  if(prv1>0){
     wx.request({
       url: config.domain+':8070/findAudioUrl?chapterId=' + this.data.audios[prv1-1].chapterId,
       method:'get',
       success: info=>{
       this.setData({
         url: info.data.data.audioUrl,
         durationStr: this.timeFormat(this.data.audios[prv1-1].chapterDuration),
         title: this.data.audios[prv1-1].chapterTitle,
         chapterId: this.data.audios[prv1 - 1].chapterId,
         prv:prv1-1

       })
         this.play()

       }
     })
  }
  },
  onPlayNextClick: function () {
    if (this.data.prv < this.data.audios.length) {
      var prv1 = this.data.prv-1+2
      console.log(prv1)
      wx.request({
        url: config.domain+':8070/findAudioUrl?chapterId=' + this.data.audios[prv1].chapterId,
        method: 'get',
        success: info => {
          this.setData({
            url: info.data.data.audioUrl,
            durationStr: this.timeFormat(this.data.audios[prv1].chapterDuration),
            title: this.data.audios[prv1].chapterTitle,
            chapterId: this.data.audios[prv1].chapterId,
            prv: prv1

          })
          this.play()
        }
      })
    
    }
  },
  getAudios: function (e){
    wx.request({
      url: config.domain+":8070/findAudioChapter?bookId="+e  ,
      method:'get',
      success: info => {
        this.setData({
          audios:info.data.list
        })
      }
    })
  },
  initAudioContext: function () {
    var t = this;
    a.onCanplay(function () { }), 
    a.onPlay(function () {
      t.syncAudioContentToUI();
    }),
     a.onTimeUpdate(function () {
      t.syncAudioContentToUI();
    }), 
    a.onPause(function () {
      t.syncAudioContentToUI();
    }),
     a.onEnded(function () {
      t.onPlayNextClick();
    }), this.play();
  },
  play: function () {
    a.epname = this.data.name, a.title = this.data.title, a.coverImgUrl = this.data.cover,
      this.normalizeUrl(a.src) !== this.normalizeUrl(this.data.url) && (a.src = this.data.url,
        a.play());
  },
  syncAudioContentToUI: function () {
    var t = {
      isPlay: !a.paused,
      currentTimeStr: this.timeFormat(a.currentTime),
    };
    this.data.preventPercentUpdate || (t.percent = Math.floor(a.currentTime / a.duration * 1e3) / 10),
      this.setData(t);
  },
 


  onSliderChange: function (t) {
    this.setData({
      preventPercentUpdate: !0
    });
  },
  onSliderDragEnd: function (t) {
    this.setData({
      preventPercentUpdate: !1
    });
    var e = a.duration * (t.detail.value / 100);
    a.seek(e);
  },
  onPlayClick: function () {
    a.src ? a.paused ? a.play() : a.pause() : this.play(this.data.url);
  },

  onJumpLeftClick: function () {
    a.seek(a.currentTime - 15);
  },
  onJumpRightClick: function () {
    a.seek(a.currentTime + 15);
  },
  timeFormat: function (t) {
    var e = parseInt(t % 60), a = parseInt(t / 60);
    return a < 10 && (a = "0" + a), e < 10 && (e = "0" + e), a + ":" + e;
  },
  normalizeUrl: function (t) {
    return (t || "").split("?")[0];
  },
  findIndexOf: function (t, e) {
    var a = -1;
    return t.forEach(function (t, o) {
      if (e(t)) return a = o, !1;
    }), a;
  },

});