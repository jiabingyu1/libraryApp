package edu.xja.digitallibrary.dao;

import edu.xja.digitallibrary.pojo.Bookshelf;
import java.util.List;
import java.util.Map;

import edu.xja.digitallibrary.pojo.Borrow;
import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.Mapper;

public interface BookshelfMapper extends Mapper<Bookshelf> {
    int updateBatch(List<Bookshelf> list);

    int batchInsert(@Param("list") List<Bookshelf> list);

    int insertOrUpdate(Bookshelf record);

    int insertOrUpdateSelective(Bookshelf record);

}