package edu.xja.digitallibrary.service.impl;

import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import edu.xja.digitallibrary.dao.AudiobookMapper;
import java.util.List;
import edu.xja.digitallibrary.pojo.Audiobook;
import edu.xja.digitallibrary.service.AudiobookService;
@Service
public class AudiobookServiceImpl implements AudiobookService{

    @Resource
    private AudiobookMapper audiobookMapper;

    @Override
    public int updateBatch(List<Audiobook> list) {
        return audiobookMapper.updateBatch(list);
    }

    @Override
    public int batchInsert(List<Audiobook> list) {
        return audiobookMapper.batchInsert(list);
    }

    @Override
    public int insertOrUpdate(Audiobook record) {
        return audiobookMapper.insertOrUpdate(record);
    }

    @Override
    public int insertOrUpdateSelective(Audiobook record) {
        return audiobookMapper.insertOrUpdateSelective(record);
    }

    @Override
    public List<Audiobook> search(Integer bookId, Integer cateId, Integer bookNo, String keyword) {
        return  audiobookMapper.searchAudio( bookId,  cateId,  bookNo, keyword);
    }

    @Override
    public Audiobook searchOne(Integer bookno) {
        return audiobookMapper.searchOne(bookno);
    }

}
