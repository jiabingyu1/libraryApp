package edu.xja.digitallibrary.config;

import org.springframework.amqp.core.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Configuration
public class BorrowQueue {
    @Bean
    DirectExchange BorrowExchange() {
        return new DirectExchange("BorrowDlExchange");
    }

    @Bean
    Queue BorrowQueue() {
        return QueueBuilder.durable("BorrowQueue")
                .withArgument("x-dead-letter-exchange", "BorrowDlExchange")
                .withArgument("x-dead-letter-routing-key", "BorrowDl")
                .withArgument("x-message-ttl", 6000)
                .build();
    }

    @Bean
    Queue BorrowDlQueue() {
        return new Queue("BorrowDlQueue", true);

    }

    @Bean
    Binding BorrowBing() {
        return BindingBuilder.bind(BorrowQueue()).to(BorrowExchange()).with(    "BorrowKey");

    }
    @Bean
    Binding BorrowDlBing(){
        return  BindingBuilder.bind(BorrowDlQueue()).to(BorrowExchange()).with("BorrowDl");
    }

}
