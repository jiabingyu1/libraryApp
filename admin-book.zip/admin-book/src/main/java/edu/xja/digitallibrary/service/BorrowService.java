package edu.xja.digitallibrary.service;

import edu.xja.digitallibrary.pojo.Borrow;

import java.util.List;
import java.util.Map;

public interface BorrowService {


    int updateBatch(List<Borrow> list);

    int batchInsert(List<Borrow> list);

    int insertOrUpdate(Borrow record);

    int insertOrUpdateSelective(Borrow record);

    int insertOne(Borrow borrow);

    List<Borrow> borrowSearch(Borrow borrow);

    List<Map> searchBorrowBook(Borrow borrow);

    int updateOneStatus(Integer borrowId, Integer status);


}
