package edu.xja.digitallibrary.utils;
import edu.xja.digitallibrary.core.filter.BookFilter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Configuration
public class FilterConfig {


    @Bean
    public FilterRegistrationBean<BookFilter> filterRegist() {
        FilterRegistrationBean<BookFilter> frBean = new FilterRegistrationBean<>();

        frBean.setFilter(new BookFilter());
        return frBean;
    }
   /* @Bean
    public FilterRegistrationBean<ChangeController> filterRegist1() {
        FilterRegistrationBean<ChangeController> frBean = new FilterRegistrationBean<>();

        frBean.setFilter(new ChangeController());
        return frBean;
    }*/

}
