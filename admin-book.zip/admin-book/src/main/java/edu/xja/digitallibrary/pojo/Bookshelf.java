package edu.xja.digitallibrary.pojo;

import javax.persistence.*;

@Table(name = "bookshelf")
public class Bookshelf {
    @Id
    @Column(name = "id")
    @GeneratedValue(generator = "JDBC")
    private Integer id;

    @Column(name = "bookid")
    private Integer bookid;

    @Column(name = "bookcate")
    private Integer bookcate;

    @Column(name = "usrno")
    private String usrno;

    @Column(name = "`status`")
    private Integer status;

    /**
     * @return id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return bookid
     */
    public Integer getBookid() {
        return bookid;
    }

    /**
     * @param bookid
     */
    public void setBookid(Integer bookid) {
        this.bookid = bookid;
    }

    /**
     * @return bookcate
     */
    public Integer getBookcate() {
        return bookcate;
    }

    /**
     * @param bookcate
     */
    public void setBookcate(Integer bookcate) {
        this.bookcate = bookcate;
    }

    /**
     * @return usrno
     */
    public String getUsrno() {
        return usrno;
    }

    /**
     * @param usrno
     */
    public void setUsrno(String usrno) {
        this.usrno = usrno;
    }

    /**
     * @return status
     */
    public Integer getStatus() {
        return status;
    }

    /**
     * @param status
     */
    public void setStatus(Integer status) {
        this.status = status;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", bookid=").append(bookid);
        sb.append(", bookcate=").append(bookcate);
        sb.append(", usrno=").append(usrno);
        sb.append(", status=").append(status);
        sb.append("]");
        return sb.toString();
    }
}