package edu.xja.digitallibrary.service;

import java.util.List;

import edu.xja.digitallibrary.pojo.Cate;
import edu.xja.digitallibrary.pojo.Readcate;

public interface ReadcateService {


    int updateBatch(List<Readcate> list);

    int batchInsert(List<Readcate> list);

    int insertOrUpdate(Readcate record);

    int insertOrUpdateSelective(Readcate record);

    List<Readcate> findAllReadCate();

    Readcate findOne(Readcate readcate);

}
