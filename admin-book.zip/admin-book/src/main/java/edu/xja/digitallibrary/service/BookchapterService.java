package edu.xja.digitallibrary.service;

import java.util.List;
import edu.xja.digitallibrary.pojo.Bookchapter;
public interface BookchapterService{


    int updateBatch(List<Bookchapter> list);

    int batchInsert(List<Bookchapter> list);

    int insertOrUpdate(Bookchapter record);

    int insertOrUpdateSelective(Bookchapter record);
    List<Bookchapter> searchAuChapter(Bookchapter record );


}
