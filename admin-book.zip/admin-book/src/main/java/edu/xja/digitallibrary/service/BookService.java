package edu.xja.digitallibrary.service;

import edu.xja.digitallibrary.pojo.Book;
import edu.xja.digitallibrary.pojo.BookIndex;
import org.springframework.stereotype.Service;

import java.util.List;

public interface BookService {
    public List<BookIndex> queryAllIndexList(Long bookId);

    public Book queryBaseInfo(Long bookId);

    public List<Book> search(int page, int pageSize,
                             String userId, String ids, String keyword, String bookStatus, Integer catId, Integer softCat, String softTag, String sortBy, String sort);

    List<BookIndex> queryNewIndexList(Long bookId);

    List<Integer> queryMaxAndMinIndexNum(Long bookId);
}
