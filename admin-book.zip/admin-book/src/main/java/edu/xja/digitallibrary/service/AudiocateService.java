package edu.xja.digitallibrary.service;

import java.util.List;
import edu.xja.digitallibrary.pojo.Audiocate;
public interface AudiocateService{


    int updateBatch(List<Audiocate> list);

    int batchInsert(List<Audiocate> list);

    int insertOrUpdate(Audiocate record);

    int insertOrUpdateSelective(Audiocate record);

    List<Audiocate> finaAllAudioCate();

}
