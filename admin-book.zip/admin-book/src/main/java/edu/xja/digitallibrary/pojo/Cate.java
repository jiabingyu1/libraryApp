package edu.xja.digitallibrary.pojo;

import javax.persistence.*;

@Table(name = "cate")
public class Cate {
    @Id
    @Column(name = "cate_id")
    @GeneratedValue(generator = "JDBC")
    private Integer cateId;

    @Column(name = "cate_name")
    private String cateName;

    /**
     * @return cate_id
     */
    public Integer getCateId() {
        return cateId;
    }

    /**
     * @param cateId
     */
    public void setCateId(Integer cateId) {
        this.cateId = cateId;
    }

    /**
     * @return cate_name
     */
    public String getCateName() {
        return cateName;
    }

    /**
     * @param cateName
     */
    public void setCateName(String cateName) {
        this.cateName = cateName;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", cateId=").append(cateId);
        sb.append(", cateName=").append(cateName);
        sb.append("]");
        return sb.toString();
    }
}