package edu.xja.digitallibrary.common.response;


import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class QueryResult<T> {
    //数据列表
    private List<T> list;
    //数据总数
    private long total;

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    private T data;
    private String msg;

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public List<T> getList() {
        return list;
    }

    public void setList(List<T> list) {
        this.list = list;
    }

    public long getTotal() {
        return total;
    }

    public void setTotal(long total) {
        this.total = total;
    }

    @Override
    public String toString() {
        return "QueryResult{" +
                "list=" + list +
                ", total=" + total +
                '}';
    }
}
