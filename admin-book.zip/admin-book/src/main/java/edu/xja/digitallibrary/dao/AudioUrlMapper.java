package edu.xja.digitallibrary.dao;

import edu.xja.digitallibrary.pojo.AudioUrl;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.Mapper;

public interface AudioUrlMapper extends Mapper<AudioUrl> {
    int updateBatch(List<AudioUrl> list);

    int batchInsert(@Param("list") List<AudioUrl> list);

    int insertOrUpdate(AudioUrl record);

    int insertOrUpdateSelective(AudioUrl record);
}