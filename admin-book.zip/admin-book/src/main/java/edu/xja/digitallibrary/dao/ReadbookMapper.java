package edu.xja.digitallibrary.dao;

import edu.xja.digitallibrary.pojo.Audiobook;
import edu.xja.digitallibrary.pojo.Readbook;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.Mapper;

public interface ReadbookMapper extends Mapper<Readbook> {
    int updateBatch(List<Readbook> list);

    int batchInsert(@Param("list") List<Readbook> list);

    int insertOrUpdate(Readbook record);

    int insertOrUpdateSelective(Readbook record);
    List<Readbook> searchRead(@Param("bookNo") Integer bookNo,
                                 @Param("cateId") Integer cateId,
                                 @Param("keyword")String keyword
                                 );
    List<Readbook>  readRank();
    List<Readbook>  homeCate();
    List<Map>  test();
 }