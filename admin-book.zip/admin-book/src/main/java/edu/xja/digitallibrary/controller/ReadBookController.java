package edu.xja.digitallibrary.controller;

import edu.xja.digitallibrary.common.response.QueryResult;
import edu.xja.digitallibrary.dao.ReadbookMapper;
import edu.xja.digitallibrary.pojo.*;
import edu.xja.digitallibrary.service.AudiobookService;
import edu.xja.digitallibrary.service.ReadbookService;
import edu.xja.digitallibrary.service.ReadcateService;
import edu.xja.digitallibrary.service.ReadurlService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@Api(value = "readbook接口", tags = "readbook的基本操作")
public class ReadBookController {
    @Autowired
    private QueryResult queryResult;
    @Autowired
    private ReadbookService readbookService;
    @Autowired
    private AudiobookService audiobookService;
    @Autowired
    private ReadcateService readcateService;
    @Autowired
    private ReadurlService readurlService;
    @Resource
    private ReadbookMapper readbookMapper;



    @ApiOperation(value = "read的查询")
    @GetMapping(value = "searchRead")
    public QueryResult searchRead(@RequestParam(value = "cateId", required = false) Integer cateId,
                                  @RequestParam(value = "bookNo", required = false) Integer bookNo,
                                  @RequestParam(value = "keyword", required = false) String keyword
    ) {
        List<Readbook> readbookList = readbookService.searchRead(bookNo, cateId, keyword);
        queryResult.setList(readbookList);
        queryResult.setTotal(readbookList.size());
        queryResult.setMsg("获取成功");
        return queryResult;
    }

    @ApiOperation(value = "ReadCate的查询")
    @GetMapping(value = "findAllReadCate")
    public QueryResult findAllReadCate() {
        List<Readcate> readcateList = readcateService.findAllReadCate();
        queryResult.setList(readcateList);
        queryResult.setTotal(readcateList.size());
        queryResult.setMsg("获取成功");
        return queryResult;

    }

    @ApiOperation(value = "ReadUrl的查询")
    @GetMapping(value = "findReadUrl")
    public QueryResult findReadUrl(Readurl readurl) {
        Readurl readUrl1 = readurlService.findOneReadUrl(readurl);
        queryResult.setData(readUrl1);
        queryResult.setMsg("获取成功");
        return queryResult;


    }

    @ApiOperation(value = "阅读排行榜（假）")
    @GetMapping(value = "readrank")
    public QueryResult readRank() {
        List<Readbook> readbookList = readbookService.readRank();
        queryResult.setList(readbookList);
        queryResult.setTotal(readbookList.size());
        queryResult.setMsg("获取成功");
        return queryResult;
    }

    @GetMapping(value = "homeCate")
    @ApiOperation(value = "首页分类")
    public QueryResult homeCate() {
        Integer cate[] = {1, 2, 4, 7};
        List<Object> list = new ArrayList<>();
        for (int i = 0; i < cate.length; i++) {
            Readcate readcate = new Readcate();
            readcate.setId(cate[i]);
            List<Readbook> readbookList = readbookService.searchRead(null, cate[i], null);
            HomeCate homeCate = new HomeCate();
            homeCate.setCatId(cate[i]);
            homeCate.setCatName(readcateService.findOne(readcate).getCataid());
            homeCate.setReadbookList(readbookList);
            list.add(homeCate);
        }
        queryResult.setData(list);
        queryResult.setMsg("成功");
        return queryResult;

    }





    /**********************************************************************************************/
    @GetMapping(value = "homeCateOne")
    @ApiOperation(value = "书籍分类")
    public QueryResult homeCateOne(Integer catId) {
        List<Object> list = new ArrayList<>();
        Integer cate[] = {1, 2, 4, 7};
        for (int i = 0; i < cate.length; i++) {
            Readcate readcate = new Readcate();
            if(cate[i] == catId) {
                readcate.setId(cate[i]);
                List<Readbook> readbookList = readbookService.searchRead(null, cate[i], null);
                HomeCate homeCate = new HomeCate();
                homeCate.setCatName(readcateService.findOne(readcate).getCataid());
                homeCate.setReadbookList(readbookList);
                list.add(homeCate);
            }
        }
        queryResult.setData(list);
        queryResult.setMsg("成功");
        return queryResult;
    }
    /**********************************************************************************************/





    @GetMapping(value = "searchAllCate")
    @ApiOperation(value = "搜索书籍")
    public  QueryResult  searchAllCate( @RequestParam(value = "keyword", required = false)String keyword){
        Map<Object,Object> resList=new HashMap<>();
        List<Readbook> readbookList = readbookService.searchRead(null, null, keyword);
        List<Audiobook> audiobookList = audiobookService.search(null, null, null,keyword);
        resList.put("图书",readbookList);
        resList.put("听书",audiobookList);
        queryResult.setData(resList);
        queryResult.setMsg("ok");
        return queryResult;
    }
    @GetMapping(value = "test10" )
    @ApiOperation(value = "aaaaaaaaaaaaaaaaaaa")
    public List  test(){
        System.out.println("aaaaaaaaaaa");
        List<Map> a = readbookMapper.test();
        System.out.println(a.get(0));
         return  a;
    }
}
