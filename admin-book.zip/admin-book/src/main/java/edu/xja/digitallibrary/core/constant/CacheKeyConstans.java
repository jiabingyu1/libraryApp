package edu.xja.digitallibrary.core.constant;

public class CacheKeyConstans {
    public static final String HOT_BOOK_LIST_KEY = "hotBookListKey";
    public static final String NEWST_BOOK_LIST_KEY = "newstBookListKey";
    public static final String BOOK_CONTENT_KEY_PREFIX = "bookContentKeyPrefix";
    public static final String EMAIL_URL_PREFIX_KEY = "emailUrlPrefixKey";
    public static final String RANDOM_NEWS_CONTENT_KEY = "randomNewsContentKey";
    public static final String REC_BOOK_LIST_KEY = "recBookListKey";
}
