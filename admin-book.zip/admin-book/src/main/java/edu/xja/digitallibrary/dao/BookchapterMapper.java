package edu.xja.digitallibrary.dao;

import edu.xja.digitallibrary.pojo.Bookchapter;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.Mapper;

public interface BookchapterMapper extends Mapper<Bookchapter> {
    int updateBatch(List<Bookchapter> list);

    int batchInsert(@Param("list") List<Bookchapter> list);

    int insertOrUpdate(Bookchapter record);

    int insertOrUpdateSelective(Bookchapter record);
}