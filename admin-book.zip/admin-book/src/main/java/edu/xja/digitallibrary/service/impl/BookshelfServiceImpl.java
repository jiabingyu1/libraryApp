package edu.xja.digitallibrary.service.impl;

import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import edu.xja.digitallibrary.pojo.Bookshelf;
import java.util.List;
import edu.xja.digitallibrary.dao.BookshelfMapper;
import edu.xja.digitallibrary.service.BookshelfService;
@Service
public class BookshelfServiceImpl implements BookshelfService{

    @Resource
    private BookshelfMapper bookshelfMapper;

    @Override
    public int updateBatch(List<Bookshelf> list) {
        return bookshelfMapper.updateBatch(list);
    }

    @Override
    public int batchInsert(List<Bookshelf> list) {
        return bookshelfMapper.batchInsert(list);
    }

    @Override
    public int insertOrUpdate(Bookshelf record) {
        return bookshelfMapper.insertOrUpdate(record);
    }

    @Override
    public int insertOrUpdateSelective(Bookshelf record) {
        return bookshelfMapper.insertOrUpdateSelective(record);
    }

    @Override
    public int insertBookshelf(Bookshelf bookshelf) {
        return bookshelfMapper.insert(bookshelf);
    }

    @Override
    public List<Bookshelf> searchBookshelf(Bookshelf bookshelf) {
        return bookshelfMapper.select(bookshelf);
    }

    @Override
    public int deleBookshelf(Bookshelf bookshelf) {
        return bookshelfMapper.delete(bookshelf);
    }



}
