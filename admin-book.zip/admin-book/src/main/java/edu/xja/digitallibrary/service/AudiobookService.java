package edu.xja.digitallibrary.service;

import java.util.List;
import edu.xja.digitallibrary.pojo.Audiobook;
import org.apache.ibatis.annotations.Param;

public interface AudiobookService{


    int updateBatch(List<Audiobook> list);

    int batchInsert(List<Audiobook> list);

    int insertOrUpdate(Audiobook record);

    int insertOrUpdateSelective(Audiobook record);

    List<Audiobook> search (@Param("bookId") Integer bookId,
                            @Param("cateId") Integer cateId,
                            @Param("bookNo")Integer bookNo,
                            @Param("keyword")String keyword );
    Audiobook searchOne(Integer bookno);

}
