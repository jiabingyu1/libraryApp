package edu.xja.digitallibrary.service.impl;

import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import edu.xja.digitallibrary.pojo.Readcate;
import edu.xja.digitallibrary.dao.ReadcateMapper;
import edu.xja.digitallibrary.service.ReadcateService;
@Service
public class ReadcateServiceImpl implements ReadcateService{

    @Resource
    private ReadcateMapper readcateMapper;

    @Override
    public int updateBatch(List<Readcate> list) {
        return readcateMapper.updateBatch(list);
    }

    @Override
    public int batchInsert(List<Readcate> list) {
        return readcateMapper.batchInsert(list);
    }

    @Override
    public int insertOrUpdate(Readcate record) {
        return readcateMapper.insertOrUpdate(record);
    }

    @Override
    public int insertOrUpdateSelective(Readcate record) {
        return readcateMapper.insertOrUpdateSelective(record);
    }

    @Override
    public List<Readcate> findAllReadCate() {
        return readcateMapper.selectAll();
    }

    @Override
    public Readcate findOne(Readcate readcate) {
        return readcateMapper.selectOne(readcate);
    }

}
