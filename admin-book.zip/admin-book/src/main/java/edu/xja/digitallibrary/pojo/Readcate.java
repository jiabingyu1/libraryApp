package edu.xja.digitallibrary.pojo;

import javax.persistence.*;

@Table(name = "readcate")
public class Readcate {
    @Id
    @Column(name = "id")
    @GeneratedValue(generator = "JDBC")
    private Integer id;

    @Column(name = "cataId")
    private String cataid;

    /**
     * @return id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return cataId
     */
    public String getCataid() {
        return cataid;
    }

    /**
     * @param cataid
     */
    public void setCataid(String cataid) {
        this.cataid = cataid;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", cataid=").append(cataid);
        sb.append("]");
        return sb.toString();
    }
}