package edu.xja.digitallibrary.service.impl;

import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import edu.xja.digitallibrary.pojo.AudioUrl;
import java.util.List;
import edu.xja.digitallibrary.dao.AudioUrlMapper;
import edu.xja.digitallibrary.service.AudioUrlService;
@Service
public class AudioUrlServiceImpl implements AudioUrlService{

    @Resource
    private AudioUrlMapper audioUrlMapper;

    @Override
    public int updateBatch(List<AudioUrl> list) {
        return audioUrlMapper.updateBatch(list);
    }

    @Override
    public int batchInsert(List<AudioUrl> list) {
        return audioUrlMapper.batchInsert(list);
    }

    @Override
    public int insertOrUpdate(AudioUrl record) {
        return audioUrlMapper.insertOrUpdate(record);
    }

    @Override
    public int insertOrUpdateSelective(AudioUrl record) {
        return audioUrlMapper.insertOrUpdateSelective(record);
    }

    @Override
    public AudioUrl findOneAuUrl(AudioUrl audioUrl) {
        return audioUrlMapper.selectOne(audioUrl);
    }

}
