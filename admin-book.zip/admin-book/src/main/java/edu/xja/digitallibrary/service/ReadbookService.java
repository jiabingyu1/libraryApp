package edu.xja.digitallibrary.service;

import java.util.List;

import edu.xja.digitallibrary.pojo.Readbook;
import org.apache.ibatis.annotations.Param;

public interface ReadbookService {


    int updateBatch(List<Readbook> list);

    int batchInsert(List<Readbook> list);

    int insertOrUpdate(Readbook record);

    int insertOrUpdateSelective(Readbook record);

    List<Readbook> searchRead(@Param("bookNo") Integer bookNo,
                              @Param("cateId") Integer cateId,
                              @Param("keyword") String keyword
    );

    Readbook searchOne(Readbook readbook);

    List<Readbook> readRank();

    List<Readbook> homeCate();


}
