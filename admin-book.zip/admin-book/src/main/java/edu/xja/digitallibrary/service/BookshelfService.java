package edu.xja.digitallibrary.service;

import edu.xja.digitallibrary.pojo.Bookshelf;

import java.util.List;

public interface BookshelfService {


    int updateBatch(List<Bookshelf> list);

    int batchInsert(List<Bookshelf> list);

    int insertOrUpdate(Bookshelf record);

    int insertOrUpdateSelective(Bookshelf record);

    int insertBookshelf(Bookshelf bookshelf);

    List<Bookshelf> searchBookshelf(Bookshelf bookshelf);

    int   deleBookshelf(Bookshelf bookshelf);

}
