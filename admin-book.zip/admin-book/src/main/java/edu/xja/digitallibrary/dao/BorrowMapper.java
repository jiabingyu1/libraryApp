package edu.xja.digitallibrary.dao;

import edu.xja.digitallibrary.pojo.Borrow;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.Mapper;

public interface BorrowMapper extends Mapper<Borrow> {
    int updateBatch(List<Borrow> list);

    int batchInsert(@Param("list") List<Borrow> list);

    int insertOrUpdate(Borrow record);

    int insertOrUpdateSelective(Borrow record);

    List<Map> searchBorrowBook(Borrow borrow);

    int updateOneStatus(Integer borrowId, Integer status);

}