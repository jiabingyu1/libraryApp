package edu.xja.digitallibrary.service;

import java.util.List;
import edu.xja.digitallibrary.pojo.BookContent;
import  edu.xja.digitallibrary.pojo.Book;

public interface BookContentService{
    public BookContent queryBookContent(Long bookId, Integer indexNum);
    public String queryIndexNameByBookIdAndIndexNum(Long bookId, Integer indexNum);
    public List<Integer> queryPreAndNextIndexNum(Long bookId, Integer indexNum);
    public  Book queryBaseInfo(Long bookId);
}
