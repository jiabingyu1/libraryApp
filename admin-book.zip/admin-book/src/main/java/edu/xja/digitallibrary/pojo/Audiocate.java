package edu.xja.digitallibrary.pojo;

import javax.persistence.*;

@Table(name = "audiocate")
public class Audiocate {
    @Id
    @Column(name = "id")
    private Integer id;

    @Column(name = "catename")
    private String catename;

    /**
     * @return id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return catename
     */
    public String getCatename() {
        return catename;
    }

    /**
     * @param catename
     */
    public void setCatename(String catename) {
        this.catename = catename;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", catename=").append(catename);
        sb.append("]");
        return sb.toString();
    }
}