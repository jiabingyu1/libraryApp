package edu.xja.digitallibrary.dao;

import edu.xja.digitallibrary.pojo.Audiocate;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.Mapper;

public interface AudiocateMapper extends Mapper<Audiocate> {
    int updateBatch(List<Audiocate> list);

    int batchInsert(@Param("list") List<Audiocate> list);

    int insertOrUpdate(Audiocate record);

    int insertOrUpdateSelective(Audiocate record);

}