package edu.xja.digitallibrary.controller;

import edu.xja.digitallibrary.pojo.AudioUrl;
import edu.xja.digitallibrary.pojo.Audiobook;
import edu.xja.digitallibrary.pojo.Audiocate;
import edu.xja.digitallibrary.pojo.Bookchapter;
import edu.xja.digitallibrary.service.AudioUrlService;
import edu.xja.digitallibrary.service.AudiobookService;
import edu.xja.digitallibrary.service.AudiocateService;
import edu.xja.digitallibrary.service.BookchapterService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import edu.xja.digitallibrary.common.response.QueryResult;

import java.util.List;

@RestController
@Api(value = "audiobook接口", tags = "audiobook的基本操作")
public class AudioBookController {
    @Autowired
    private QueryResult queryResult;
    @Autowired
    private AudiobookService audiobookService;
    @Autowired
    private AudiocateService audiocateService;
    @Autowired
    private BookchapterService bookchapterService;
    @Autowired
    private AudioUrlService audioUrlService;

    @ApiOperation(value = "audio的查询")
    @GetMapping(value = "searchAudio")
    public QueryResult searchAudio(@RequestParam(value = "bookId", required = false) Integer bookId,
                                   @RequestParam(value = "cateId", required = false) Integer cateId,
                                   @RequestParam(value = "bookNo", required = false) Integer bookNo,
                                   @RequestParam(value = "keyword", required = false) String keyword
                                  ) {
        try {
            List<Audiobook> audiobookList = audiobookService.search(bookId, cateId, bookNo,keyword);
            queryResult.setList(audiobookList);
            queryResult.setMsg("成功获取");
            queryResult.setTotal(audiobookList.size());
            return queryResult;
        } catch (Exception e) {
            queryResult.setMsg("系统出错");
            return queryResult;
        }

    }

    @ApiOperation(value = "audioCate的查询")
    @GetMapping(value = "findAllCate")
    public QueryResult findAllCate() {
        try {
            List<Audiocate> audiocateList = audiocateService.finaAllAudioCate();
            queryResult.setList(audiocateList);
            queryResult.setTotal(audiocateList.size());
            queryResult.setMsg("获取成功");
            return queryResult;
        } catch (Exception e) {
            queryResult.setData("系统出错");
            return queryResult;
        }
    }

    @ApiOperation(value = "audio章节的查询")
    @GetMapping(value = "findAudioChapter")
    public QueryResult findAudioChapter(Bookchapter bookchapter) {
        try {
            List<Bookchapter> bookchapterList = bookchapterService.searchAuChapter(bookchapter);
            queryResult.setList(bookchapterList);
            queryResult.setMsg("成功获取");
            queryResult.setTotal(bookchapterList.size());
            return queryResult;
        } catch (Exception e) {
            queryResult.setData("系统出错");
            return queryResult;
        }
    }

    @ApiOperation(value = "audio章节Url的查询")
    @GetMapping(value = "findAudioUrl")
    public QueryResult findAudioUrl(AudioUrl audioUrl) {
        try {
            AudioUrl audioUrl1 = audioUrlService.findOneAuUrl(audioUrl);
            queryResult.setData(audioUrl1);
            queryResult.setMsg("获取成功");
            return queryResult;
        } catch (Exception e) {
            queryResult.setData("系统出错");
            return queryResult;
        }
    }


}
