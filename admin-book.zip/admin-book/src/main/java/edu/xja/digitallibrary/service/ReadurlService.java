package edu.xja.digitallibrary.service;

import java.util.List;

import edu.xja.digitallibrary.pojo.Readurl;

public interface ReadurlService {


    int updateBatch(List<Readurl> list);

    int batchInsert(List<Readurl> list);

    int insertOrUpdate(Readurl record);

    int insertOrUpdateSelective(Readurl record);

    Readurl findOneReadUrl(Readurl readurl);

}
