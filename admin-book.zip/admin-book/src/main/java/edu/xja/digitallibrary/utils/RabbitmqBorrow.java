//package edu.xja.digitallibrary.utils;
//
//import edu.xja.digitallibrary.pojo.Borrow;
//import edu.xja.digitallibrary.service.BorrowService;
//import org.springframework.amqp.rabbit.annotation.RabbitListener;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.text.ParseException;
//import java.text.SimpleDateFormat;
//import java.util.Date;
//
//@Service
//public class RabbitmqBorrow {
//    @Autowired
//    BorrowService borrowService;
//
//    @RabbitListener(queues = "BorrowDlQueue")
//    public void BorrowRemend(Borrow borrow) {
//        //测试使用  上线后可修改指定时间
//        if (borrow.getStatus() == 0 && timeDifference(borrow.getStartTime()) >= 0) {
//            borrow.setStatus(4);
//            borrowService.insertOrUpdate(borrow);
//        }
//
//
//    }
//
//    public int timeDifference(String pastTime) {
//        Date date = new Date();
//
//        SimpleDateFormat simpleFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//        String newTime = simpleFormat.format(date);
//        System.out.println(pastTime + "                            " + newTime);
//        try {
//            Date pastTime1 = simpleFormat.parse(pastTime);
//            Date newTime1 = simpleFormat.parse(newTime);
//            long pastTime2 = pastTime1.getTime();
//            long newTime2 = newTime1.getTime();
//            int minutes = (int) ((newTime2 - pastTime2) / (1000 * 60));
//            return minutes;
//        } catch (ParseException e) {
//            return 0;
//        }
//
//
//    }
//}
