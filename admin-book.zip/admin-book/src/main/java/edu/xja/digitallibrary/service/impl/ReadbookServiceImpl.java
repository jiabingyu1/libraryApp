package edu.xja.digitallibrary.service.impl;

import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import edu.xja.digitallibrary.dao.ReadbookMapper;
import java.util.List;
import edu.xja.digitallibrary.pojo.Readbook;
import edu.xja.digitallibrary.service.ReadbookService;
@Service
public class ReadbookServiceImpl implements ReadbookService{

    @Resource
    private ReadbookMapper readbookMapper;

    @Override
    public int updateBatch(List<Readbook> list) {
        return readbookMapper.updateBatch(list);
    }

    @Override
    public int batchInsert(List<Readbook> list) {
        return readbookMapper.batchInsert(list);
    }

    @Override
    public int insertOrUpdate(Readbook record) {
        return readbookMapper.insertOrUpdate(record);
    }

    @Override
    public int insertOrUpdateSelective(Readbook record) {
        return readbookMapper.insertOrUpdateSelective(record);
    }

    @Override
    public List<Readbook> searchRead(Integer bookNo, Integer cateId, String keyword) {
        return readbookMapper.searchRead(bookNo,cateId,keyword);
    }

    @Override
    public Readbook searchOne(Readbook readbook) {
        return readbookMapper.selectOne(readbook);
    }

    @Override
    public List<Readbook> readRank() {
        return readbookMapper.readRank();
    }



    public List<Readbook> homeCate() {
        return readbookMapper.homeCate();
    }


}
