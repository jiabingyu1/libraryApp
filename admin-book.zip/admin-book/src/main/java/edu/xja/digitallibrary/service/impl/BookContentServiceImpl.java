package edu.xja.digitallibrary.service.impl;

import edu.xja.digitallibrary.common.cache.CommonCacheUtil;
import edu.xja.digitallibrary.dao.BookContentMapper;
import edu.xja.digitallibrary.dao.BookIndexMapper;
import edu.xja.digitallibrary.dao.BookMapper;
import edu.xja.digitallibrary.pojo.BookContent;
import edu.xja.digitallibrary.pojo.BookContentExample;
import edu.xja.digitallibrary.pojo.BookIndex;
import edu.xja.digitallibrary.pojo.BookIndexExample;
import  edu.xja.digitallibrary.pojo.Book;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

import edu.xja.digitallibrary.service.BookContentService;

@Service
public class BookContentServiceImpl implements BookContentService{

    @Resource
    private BookContentMapper bookContentMapper;
    @Resource
    private CommonCacheUtil cacheUtil;
  @Resource
  private BookIndexMapper bookIndexMapper;
  @Resource
  private BookMapper bookMapper;

    public BookContent queryBookContent(Long bookId, Integer indexNum) {
        BookContent content = null;
        System.out.println(content);

        if (content == null) {
            BookContentExample example = new BookContentExample();
            example.createCriteria().andBookIdEqualTo(bookId).andIndexNumEqualTo(indexNum);
            List<BookContent> bookContents = bookContentMapper.selectByExample(example);
            content = bookContents.size() > 0 ? bookContents.get(0) : null;

        }


        return content;
    }
    /**
     * 查询章节名
     * */
    public String queryIndexNameByBookIdAndIndexNum(Long bookId, Integer indexNum) {

        BookIndexExample example = new BookIndexExample();
        example.createCriteria().andBookIdEqualTo(bookId).andIndexNumEqualTo(indexNum);
        List<BookIndex> indexList = bookIndexMapper.selectByExample(example);
        if(indexList != null && indexList.size() > 0 ) {
            return indexList.get(0).getIndexName();
        }
        return null;
    }
    /**
     * 查询前一章节和后一章节号
     * */
    public List<Integer> queryPreAndNextIndexNum(Long bookId, Integer indexNum) {
        List<Integer> result = new ArrayList<>();
        BookIndexExample example = new BookIndexExample();
        example.createCriteria().andBookIdEqualTo(bookId).andIndexNumGreaterThan(indexNum);
        example.setOrderByClause("index_num asc");
        List<BookIndex> bookIndices = bookIndexMapper.selectByExample(example);
        if (bookIndices.size() > 0) {
            result.add(bookIndices.get(0).getIndexNum());
        } else {
            result.add(indexNum);
        }
        example = new BookIndexExample();
        example.createCriteria().andBookIdEqualTo(bookId).andIndexNumLessThan(indexNum);
        example.setOrderByClause("index_num DESC");
        bookIndices = bookIndexMapper.selectByExample(example);
        if (bookIndices.size() > 0) {
            result.add(bookIndices.get(0).getIndexNum());
        } else {
            result.add(indexNum);
        }
        return result;

    }
    /**
     * 查询书籍的基础数据
     * */
    public Book queryBaseInfo(Long bookId) {

        return bookMapper.selectByPrimaryKey(bookId);
    }

}
