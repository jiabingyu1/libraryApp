package edu.xja.digitallibrary.dao;

import edu.xja.digitallibrary.pojo.Readurl;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.Mapper;

public interface ReadurlMapper extends Mapper<Readurl> {
    int updateBatch(List<Readurl> list);

    int batchInsert(@Param("list") List<Readurl> list);

    int insertOrUpdate(Readurl record);

    int insertOrUpdateSelective(Readurl record);
}