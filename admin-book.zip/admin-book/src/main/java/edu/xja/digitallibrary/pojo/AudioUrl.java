package edu.xja.digitallibrary.pojo;

import javax.persistence.*;

@Table(name = "audio_url")
public class AudioUrl {
    @Id
    @Column(name = "id")
    @GeneratedValue(generator = "JDBC")
    private Integer id;

    @Column(name = "audio_Url")
    private String audioUrl;

    @Column(name = "bookON")
    private Integer bookon;

    @Column(name = "chapter_Id")
    private Integer chapterId;

    /**
     * @return id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return audio_Url
     */
    public String getAudioUrl() {
        return audioUrl;
    }

    /**
     * @param audioUrl
     */
    public void setAudioUrl(String audioUrl) {
        this.audioUrl = audioUrl;
    }

    /**
     * @return bookON
     */
    public Integer getBookon() {
        return bookon;
    }

    /**
     * @param bookon
     */
    public void setBookon(Integer bookon) {
        this.bookon = bookon;
    }

    /**
     * @return chapter_Id
     */
    public Integer getChapterId() {
        return chapterId;
    }

    /**
     * @param chapterId
     */
    public void setChapterId(Integer chapterId) {
        this.chapterId = chapterId;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", audioUrl=").append(audioUrl);
        sb.append(", bookon=").append(bookon);
        sb.append(", chapterId=").append(chapterId);
        sb.append("]");
        return sb.toString();
    }
}