package edu.xja.digitallibrary.dao;

import edu.xja.digitallibrary.pojo.Cate;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.Mapper;

public interface CateMapper extends Mapper<Cate> {
    int batchInsert(@Param("list") List<Cate> list);
}