package edu.xja.digitallibrary.service;

import edu.xja.digitallibrary.pojo.Cate;

import java.util.List;
public interface CateService{


    int batchInsert(List<Cate> list);
    List<Cate>  selectAllCate();

}
