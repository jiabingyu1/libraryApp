package edu.xja.digitallibrary.controller;

import edu.xja.digitallibrary.pojo.Cate;
import edu.xja.digitallibrary.service.CateService;
import io.swagger.annotations.Api;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

@RestController
@Api(value = "分类接口", tags = "分类的基本操作")
public class CateController {
    @Resource
    public CateService cateService;

    @GetMapping(value = "allCate")
    @ResponseBody
    public List<Cate> selectAllSort() {
        List<Cate> cateList = cateService.selectAllCate();
        return cateList;
    }
}
