package edu.xja.digitallibrary.dao;

import edu.xja.digitallibrary.pojo.Readcate;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.Mapper;

public interface ReadcateMapper extends Mapper<Readcate> {
    int updateBatch(List<Readcate> list);

    int batchInsert(@Param("list") List<Readcate> list);

    int insertOrUpdate(Readcate record);

    int insertOrUpdateSelective(Readcate record);
}