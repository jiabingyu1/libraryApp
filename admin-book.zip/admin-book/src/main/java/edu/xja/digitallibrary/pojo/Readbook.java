package edu.xja.digitallibrary.pojo;

import javax.persistence.*;

@Table(name = "readbook")
public class Readbook {
    @Id
    @Column(name = "id")
    @GeneratedValue(generator = "JDBC")
    private Integer id;

    @Column(name = "bookNo")
    private String bookno;

    @Column(name = "author")
    private String author;

    @Column(name = "bookName")
    private String bookname;

    @Column(name = "catId")
    private Integer catid;

    @Column(name = "coverUrl")
    private String coverurl;

    @Column(name = "intro")
    private String intro;

    @Column(name = "pageNumber")
    private Integer pagenumber;

    @Column(name = "publish")
    private String publish;

    @Column(name = "publisDate")
    private String publisdate;

    @Column(name = "`status`")
    private Integer status;

    /**
     * @return id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return bookNo
     */
    public String getBookno() {
        return bookno;
    }

    /**
     * @param bookno
     */
    public void setBookno(String bookno) {
        this.bookno = bookno;
    }

    /**
     * @return author
     */
    public String getAuthor() {
        return author;
    }

    /**
     * @param author
     */
    public void setAuthor(String author) {
        this.author = author;
    }

    /**
     * @return bookName
     */
    public String getBookname() {
        return bookname;
    }

    /**
     * @param bookname
     */
    public void setBookname(String bookname) {
        this.bookname = bookname;
    }

    /**
     * @return catId
     */
    public Integer getCatid() {
        return catid;
    }

    /**
     * @param catid
     */
    public void setCatid(Integer catid) {
        this.catid = catid;
    }

    /**
     * @return coverUrl
     */
    public String getCoverurl() {
        return coverurl;
    }

    /**
     * @param coverurl
     */
    public void setCoverurl(String coverurl) {
        this.coverurl = coverurl;
    }

    /**
     * @return intro
     */
    public String getIntro() {
        return intro;
    }

    /**
     * @param intro
     */
    public void setIntro(String intro) {
        this.intro = intro;
    }

    /**
     * @return pageNumber
     */
    public Integer getPagenumber() {
        return pagenumber;
    }

    /**
     * @param pagenumber
     */
    public void setPagenumber(Integer pagenumber) {
        this.pagenumber = pagenumber;
    }

    /**
     * @return publish
     */
    public String getPublish() {
        return publish;
    }

    /**
     * @param publish
     */
    public void setPublish(String publish) {
        this.publish = publish;
    }

    /**
     * @return publisDate
     */
    public String getPublisdate() {
        return publisdate;
    }

    /**
     * @param publisdate
     */
    public void setPublisdate(String publisdate) {
        this.publisdate = publisdate;
    }

    /**
     * @return status
     */
    public Integer getStatus() {
        return status;
    }

    /**
     * @param status
     */
    public void setStatus(Integer status) {
        this.status = status;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", bookno=").append(bookno);
        sb.append(", author=").append(author);
        sb.append(", bookname=").append(bookname);
        sb.append(", catid=").append(catid);
        sb.append(", coverurl=").append(coverurl);
        sb.append(", intro=").append(intro);
        sb.append(", pagenumber=").append(pagenumber);
        sb.append(", publish=").append(publish);
        sb.append(", publisdate=").append(publisdate);
        sb.append(", status=").append(status);
        sb.append("]");
        return sb.toString();
    }
}