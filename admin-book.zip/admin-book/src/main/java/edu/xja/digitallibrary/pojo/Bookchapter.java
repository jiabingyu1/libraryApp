package edu.xja.digitallibrary.pojo;

import javax.persistence.*;

@Table(name = "bookchapter")
public class Bookchapter {
    @Id
    @Column(name = "id")
    @GeneratedValue(generator = "JDBC")
    private Integer id;

    @Column(name = "book_Id")
    private Integer bookId;

    @Column(name = "chapter_Sort")
    private Integer chapterSort;

    @Column(name = "chapter_Id")
    private Integer chapterId;

    @Column(name = "chapter_Duration")
    private Integer chapterDuration;

    @Column(name = "chapter_Title")
    private String chapterTitle;

    /**
     * @return id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return book_Id
     */
    public Integer getBookId() {
        return bookId;
    }

    /**
     * @param bookId
     */
    public void setBookId(Integer bookId) {
        this.bookId = bookId;
    }

    /**
     * @return chapter_Sort
     */
    public Integer getChapterSort() {
        return chapterSort;
    }

    /**
     * @param chapterSort
     */
    public void setChapterSort(Integer chapterSort) {
        this.chapterSort = chapterSort;
    }

    /**
     * @return chapter_Id
     */
    public Integer getChapterId() {
        return chapterId;
    }

    /**
     * @param chapterId
     */
    public void setChapterId(Integer chapterId) {
        this.chapterId = chapterId;
    }

    /**
     * @return chapter_Duration
     */
    public Integer getChapterDuration() {
        return chapterDuration;
    }

    /**
     * @param chapterDuration
     */
    public void setChapterDuration(Integer chapterDuration) {
        this.chapterDuration = chapterDuration;
    }

    /**
     * @return chapter_Title
     */
    public String getChapterTitle() {
        return chapterTitle;
    }

    /**
     * @param chapterTitle
     */
    public void setChapterTitle(String chapterTitle) {
        this.chapterTitle = chapterTitle;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", bookId=").append(bookId);
        sb.append(", chapterSort=").append(chapterSort);
        sb.append(", chapterId=").append(chapterId);
        sb.append(", chapterDuration=").append(chapterDuration);
        sb.append(", chapterTitle=").append(chapterTitle);
        sb.append("]");
        return sb.toString();
    }
}