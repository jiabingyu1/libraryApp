package edu.xja.digitallibrary.service.impl;

import edu.xja.digitallibrary.pojo.Cate;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import edu.xja.digitallibrary.dao.CateMapper;
import edu.xja.digitallibrary.service.CateService;
@Service
public class CateServiceImpl implements CateService{

    @Resource
    private CateMapper cateMapper;

    @Override
    public int batchInsert(List<Cate> list) {
        return cateMapper.batchInsert(list);
    }

    @Override
    public List<Cate> selectAllCate() {
        return cateMapper.selectAll();
    }

}
