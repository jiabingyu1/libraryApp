package edu.xja.digitallibrary.dao;

import edu.xja.digitallibrary.pojo.Audiobook;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.Mapper;

public interface AudiobookMapper extends Mapper<Audiobook> {
    int updateBatch(List<Audiobook> list);

    int batchInsert(@Param("list") List<Audiobook> list);

    int insertOrUpdate(Audiobook record);

    int insertOrUpdateSelective(Audiobook record);
    List<Audiobook> searchAudio (@Param("bookId") Integer bookId,
                            @Param("cateId") Integer cateId,
                            @Param("bookNo")Integer bookNo,
                            @Param("keyword")String keyword
                              );
    Audiobook searchOne(Integer bookno);
}