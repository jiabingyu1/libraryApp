package edu.xja.digitallibrary.pojo;

import javax.persistence.*;

@Table(name = "readurl")
public class Readurl {
    @Id
    @Column(name = "id")
    @GeneratedValue(generator = "JDBC")
    private Integer id;

    @Column(name = "readUrl")
    private String readurl;

    @Column(name = "bookNo")
    private Integer bookno;

    /**
     * @return id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return readUrl
     */
    public String getReadurl() {
        return readurl;
    }

    /**
     * @param readurl
     */
    public void setReadurl(String readurl) {
        this.readurl = readurl;
    }

    /**
     * @return bookNo
     */
    public Integer getBookno() {
        return bookno;
    }

    /**
     * @param bookno
     */
    public void setBookno(Integer bookno) {
        this.bookno = bookno;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", readurl=").append(readurl);
        sb.append(", bookno=").append(bookno);
        sb.append("]");
        return sb.toString();
    }
}