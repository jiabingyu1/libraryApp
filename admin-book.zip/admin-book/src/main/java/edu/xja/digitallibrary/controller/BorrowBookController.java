package edu.xja.digitallibrary.controller;

import edu.xja.digitallibrary.common.response.QueryResult;
import edu.xja.digitallibrary.pojo.Borrow;
import edu.xja.digitallibrary.service.BorrowService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

@RestController
@Api(value = "借阅管理", tags = "借阅管理")
public class BorrowBookController {
    /*  status =0 正在借阅(10天之内归还)
      status=1  已按照时间归还
      status=2已超时归还*/
    @Autowired
    QueryResult queryResult;
    @Autowired
    BorrowService borrowService;
    @Autowired
    RabbitTemplate rabbitTemplate;

    @PostMapping(value = "insertBorrowBook")
    @ApiOperation(value = "借阅数据插入")
    public QueryResult insertBorrowBook(Borrow borrow) {
        try {
            Date date = new Date();
            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String currdata = df.format(date);
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);
            calendar.add(Calendar.DATE, 10);
            String T1 = df.format(calendar.getTime());
            borrow.setStartTime(currdata);
            borrow.setEndTime(T1);
            borrowService.insertOne(borrow);
            rabbitTemplate.convertAndSend("BorrowDlExchange", "BorrowKey", borrow);
            queryResult.setTotal(0);
            queryResult.setMsg("成功借阅");
            return queryResult;

        } catch (Exception e) {
            queryResult.setTotal(1);
            queryResult.setMsg("系统出错");
            return queryResult;
        }
    }

    @GetMapping(value = "borrowSearch")
    @ApiOperation(value = "个人借书记录查询")
    public QueryResult borrowSearch(Borrow borrow) {
        List<Map> borrowList = borrowService.searchBorrowBook(borrow);
        queryResult.setList(borrowList);
        queryResult.setTotal(borrowList.size());
        queryResult.setMsg("查询成功");
        return queryResult;
    }
    @PostMapping(value = "updaBorrowStatus")
    @ApiOperation(value = "修改status")
    public  QueryResult updaBorrowStatus(Integer borrowId, Integer status){

        borrowService.updateOneStatus(borrowId,status);
         queryResult.setData("归还成功");
        return  queryResult;
    }
//    @GetMapping(value = "borrowPrompting")
////    public QueryResult borrowPrompting(Borrow borrow){
////        try {
////            List<Map> borrowList = borrowService.searchBorrowBook(borrow);
////}
////    }

}
