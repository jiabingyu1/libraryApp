package edu.xja.digitallibrary.service.impl;

import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import edu.xja.digitallibrary.pojo.Borrow;
import java.util.List;
import java.util.Map;

import edu.xja.digitallibrary.dao.BorrowMapper;
import edu.xja.digitallibrary.service.BorrowService;
@Service
public class
BorrowServiceImpl implements BorrowService{

    @Resource
    private BorrowMapper borrowMapper;

    @Override
    public int updateBatch(List<Borrow> list) {
        return borrowMapper.updateBatch(list);
    }

    @Override
    public int batchInsert(List<Borrow> list) {
        return borrowMapper.batchInsert(list);
    }

    @Override
    public int insertOrUpdate(Borrow record) {
        return borrowMapper.insertOrUpdate(record);
    }

    @Override
    public int insertOrUpdateSelective(Borrow record) {
        return borrowMapper.insertOrUpdateSelective(record);
    }

    @Override
    public int insertOne(Borrow borrow) {
        return borrowMapper.insert(borrow);
    }

    @Override
    public List<Borrow> borrowSearch(Borrow borrow) {
        return borrowMapper.select(borrow);
    }

    @Override
    public List<Map> searchBorrowBook(Borrow borrow) {
        return borrowMapper.searchBorrowBook(borrow);
    }

    @Override
    public int updateOneStatus(Integer borrowId, Integer status) {
        return borrowMapper.updateOneStatus(borrowId,status);
    }


}
