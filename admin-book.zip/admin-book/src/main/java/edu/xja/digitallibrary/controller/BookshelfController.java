package edu.xja.digitallibrary.controller;

import edu.xja.digitallibrary.common.response.QueryResult;
import edu.xja.digitallibrary.pojo.Audiobook;
import edu.xja.digitallibrary.pojo.Bookshelf;
import edu.xja.digitallibrary.pojo.Readbook;
import edu.xja.digitallibrary.service.AudiobookService;
import edu.xja.digitallibrary.service.BookshelfService;
import edu.xja.digitallibrary.service.ReadbookService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@Api(value = "用户个人书架")
public class BookshelfController {
    @Autowired
    private BookshelfService bookshelfService;
    @Autowired
    private QueryResult queryResult;
    @Autowired
    private ReadbookService readbookService;
    @Autowired
    private AudiobookService audiobookService;

    @ApiOperation(value = "查询个人书架")
    @GetMapping(value = "searchBookshelf")
    public QueryResult searchBookshelf(Bookshelf bookshelf) {
        List<Bookshelf> bookshelfList = bookshelfService.searchBookshelf(bookshelf);
        Map<Object,Object>  resultList= new HashMap<>();
        List<Readbook> readbookList=new ArrayList<>();
        List<Audiobook> audiobookList =new ArrayList<>();
        for(int i =0; i<bookshelfList.size();i++) {
            if (bookshelfList.get(i).getBookcate() == 1) {
                Readbook readbook=new Readbook();
                readbook.setBookno(bookshelfList.get(i).getBookid().toString());
                readbookList.add(readbookService.searchOne(readbook));
            } else {
                audiobookList.add(audiobookService.searchOne( bookshelfList.get(i).getBookid()));
            }
        }
          resultList.put("图书",readbookList);
          resultList.put("听书",audiobookList);
          int a=readbookList.size()+audiobookList.size();
        queryResult.setTotal(a);
        queryResult.setData(resultList);
        queryResult.setMsg("获取成功");
        return queryResult;
    }

    @ApiOperation(value = "增加书架")
    @PostMapping(value = "insertBookshelf")
    public QueryResult insertBookshelf(Bookshelf bookshelf) {
        try {
            System.out.println(bookshelf.toString());
            List<Bookshelf> bookshelfList = bookshelfService.searchBookshelf(bookshelf);
            System.out.println(bookshelfList.size());
        if(bookshelfList.size()<=0){
            bookshelfService.insertBookshelf(bookshelf);
            queryResult.setData(0);
            queryResult.setMsg("加入成功");
            return queryResult;
            }else {
                queryResult.setData(1);
                queryResult.setMsg("此书已经加入书架");
                return  queryResult;
            }
        } catch (Exception e) {
            queryResult.setMsg("系统出错");
            return queryResult;
        }

    }


    @ApiOperation(value = "删除")
    @PostMapping(value = "deleBookshelf")
    public QueryResult deleBookshelf(Bookshelf bookshelf) {
         try {
             bookshelfService.deleBookshelf(bookshelf);
             queryResult.setMsg("删除成功");
             return queryResult;

         }catch (Exception e){
             queryResult.setMsg("系统出错");
             return  queryResult;
         }
    }
}
