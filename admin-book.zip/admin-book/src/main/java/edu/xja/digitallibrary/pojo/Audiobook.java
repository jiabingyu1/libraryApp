package edu.xja.digitallibrary.pojo;

import javax.persistence.*;

@Table(name = "audiobook")
public class Audiobook {
    @Id
    @Column(name = "id")
    private Integer id;

    @Column(name = "categoryId")
    private Integer categoryid;

    @Column(name = "categoryName")
    private String categoryname;

    @Column(name = "bookNo")
    private Integer bookno;

    @Column(name = "bookName")
    private String bookname;

    @Column(name = "author")
    private String author;

    @Column(name = "louder")
    private String louder;

    @Column(name = "cover_https")
    private String coverHttps;

    @Column(name = "bookChapter")
    private Integer bookchapter;

    @Column(name = "duration")
    private Integer duration;

    @Column(name = "bookIntro")
    private String bookintro;

    /**
     * @return id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return categoryId
     */
    public Integer getCategoryid() {
        return categoryid;
    }

    /**
     * @param categoryid
     */
    public void setCategoryid(Integer categoryid) {
        this.categoryid = categoryid;
    }

    /**
     * @return categoryName
     */
    public String getCategoryname() {
        return categoryname;
    }

    /**
     * @param categoryname
     */
    public void setCategoryname(String categoryname) {
        this.categoryname = categoryname;
    }

    /**
     * @return bookNo
     */
    public Integer getBookno() {
        return bookno;
    }

    /**
     * @param bookno
     */
    public void setBookno(Integer bookno) {
        this.bookno = bookno;
    }

    /**
     * @return bookName
     */
    public String getBookname() {
        return bookname;
    }

    /**
     * @param bookname
     */
    public void setBookname(String bookname) {
        this.bookname = bookname;
    }

    /**
     * @return author
     */
    public String getAuthor() {
        return author;
    }

    /**
     * @param author
     */
    public void setAuthor(String author) {
        this.author = author;
    }

    /**
     * @return louder
     */
    public String getLouder() {
        return louder;
    }

    /**
     * @param louder
     */
    public void setLouder(String louder) {
        this.louder = louder;
    }

    /**
     * @return cover_https
     */
    public String getCoverHttps() {
        return coverHttps;
    }

    /**
     * @param coverHttps
     */
    public void setCoverHttps(String coverHttps) {
        this.coverHttps = coverHttps;
    }

    /**
     * @return bookChapter
     */
    public Integer getBookchapter() {
        return bookchapter;
    }

    /**
     * @param bookchapter
     */
    public void setBookchapter(Integer bookchapter) {
        this.bookchapter = bookchapter;
    }

    /**
     * @return duration
     */
    public Integer getDuration() {
        return duration;
    }

    /**
     * @param duration
     */
    public void setDuration(Integer duration) {
        this.duration = duration;
    }

    /**
     * @return bookIntro
     */
    public String getBookintro() {
        return bookintro;
    }

    /**
     * @param bookintro
     */
    public void setBookintro(String bookintro) {
        this.bookintro = bookintro;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", categoryid=").append(categoryid);
        sb.append(", categoryname=").append(categoryname);
        sb.append(", bookno=").append(bookno);
        sb.append(", bookname=").append(bookname);
        sb.append(", author=").append(author);
        sb.append(", louder=").append(louder);
        sb.append(", coverHttps=").append(coverHttps);
        sb.append(", bookchapter=").append(bookchapter);
        sb.append(", duration=").append(duration);
        sb.append(", bookintro=").append(bookintro);
        sb.append("]");
        return sb.toString();
    }
}