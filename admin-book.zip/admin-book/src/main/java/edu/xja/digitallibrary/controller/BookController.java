package edu.xja.digitallibrary.controller;

import com.github.pagehelper.PageInfo;
import edu.xja.digitallibrary.core.config.SeoConfig;
import edu.xja.digitallibrary.core.utils.CatUtil;
import edu.xja.digitallibrary.core.utils.Constants;
import edu.xja.digitallibrary.pojo.BookContent;
import edu.xja.digitallibrary.pojo.BookIndex;
import edu.xja.digitallibrary.service.BookContentService;
import edu.xja.digitallibrary.pojo.Book;
import edu.xja.digitallibrary.service.BookService;
import edu.xja.digitallibrary.vo.BookVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.text.StringEscapeUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import io.swagger.annotations.Api;
import org.thymeleaf.standard.expression.Each;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.*;

@RestController
@Api(value = "图书接口", tags = "图书的基本操作")

public class BookController {
    @Resource
    private BookContentService bookContentService;
    @Resource
    private BookService bookService;

    @ApiOperation(value = "数据的查询")
    @GetMapping(value = "search")
    @ResponseBody
    public List<Book> search(@RequestParam(value = "curr", defaultValue = "1") int page, @RequestParam(value = "limit", defaultValue = "20") int pageSize,
                             @RequestParam(value = "keyword", required = false) String keyword, @RequestParam(value = "catId", required = false) Integer catId,
                             @RequestParam(value = "historyBookIds", required = false) String ids,
                             @RequestParam(value = "bookStatus", required = false) String bookStatus,
                             @RequestParam(value = "token", required = false) String token,
                             @RequestParam(value = "sortBy", defaultValue = "update_time") String sortBy,
                             @RequestParam(value = "sort", defaultValue = "DESC") String sort, ModelMap modelMap) {
        String userId = null;
        List<Book> books;
        List<BookVO> bookVoList;
        if (StringUtils.isEmpty(ids) || !StringUtils.isEmpty(keyword)) {
            books = bookService.search(page, pageSize, userId, ids, keyword, bookStatus, catId, null, null, sortBy, sort);
            bookVoList = new ArrayList<>();
            for (Book book : books) {
                BookVO bookvo = new BookVO();
                BeanUtils.copyProperties(book, bookvo);
                bookvo.setCateName(CatUtil.getCatNameById(bookvo.getCatid()));
                bookVoList.add(bookvo);
            }

        } else {
            if (!ids.contains(Constants.BOOK_ID_SEPARATOR)) {
                books = bookService.search(page, 50, null, ids, keyword, null, catId, null, null, sortBy, sort);
                List<String> idsArr = Arrays.asList(ids.split(","));
                BookVO[] bookVoArr = new BookVO[books.size()];
                for (Book book : books) {
                    int index = idsArr.indexOf(book.getId() + "");
                    BookVO bookvo = new BookVO();
                    BeanUtils.copyProperties(book, bookvo);
                    bookvo.setCateName(CatUtil.getCatNameById(bookvo.getCatid()));
                    bookVoArr[books.size() - index - 1] = bookvo;
                }
                bookVoList = Arrays.asList(bookVoArr);
            } else {
                books = new ArrayList<>();
                bookVoList = new ArrayList<>();
            }

        }

        PageInfo<Book> bookPageInfo = new PageInfo<>(books);
      /*  modelMap.put("limit", bookPageInfo.getPageSize());
        modelMap.put("curr", bookPageInfo.getPageNum());
        modelMap.put("total", bookPageInfo.getTotal());
        modelMap.put("books", bookVoList);
        modelMap.put("ids", ids);
        modelMap.put("token", token);
        modelMap.put("bookStatus", bookStatus);
        modelMap.put("keyword", keyword);
        modelMap.put("catId", catId);
        modelMap.put("sortBy", sortBy);
        modelMap.put("sort", sort);*/
        return books;
    }

    /**
     * 书籍目录
     */
    @ApiOperation(value = "图书的全部目录")
    @GetMapping(value = "{bookId}/index.html")
    @ResponseBody
    public List<BookIndex> bookIndex(@PathVariable("bookId") Long bookId, HttpServletRequest req, ModelMap modelMap) {
        List<BookIndex> indexList = bookService.queryAllIndexList(bookId);
        String bookName = bookService.queryBaseInfo(bookId).getBookName();
     /*   modelMap.put("indexList", indexList);
        modelMap.put("bookName", bookName);
        modelMap.put("bookId", bookId);*/
        /*SeoConfig seoConfig = (SeoConfig) req.getServletContext().getAttribute(Constants.SEO_CONFIG_KEY);

         *//*Map<String, String> page = seoConfig.getPage();
        modelMap.put("title", page.get("catalog.title").replaceAll("<bookName>", bookName));
        modelMap.put("keyword", page.get("catalog.keyword").replaceAll("<bookName>", bookName));
        modelMap.put("description", page.get("catalog.description").replaceAll("<bookName>", bookName));*/
/*        Map<String, Object> map = new HashMap<String, Object>();
        map.put("indexList", indexList);
        map.put("bookName", bookName);
        map.put("bookId", bookId);*/
        return indexList;
    }

    /**
     * 书籍内容页
     */
    @ApiOperation(value = "图书的内容")
    @GetMapping(value = "{bookId}/{indexNum}.html")
    @ResponseBody
    public BookContent bookContent(@PathVariable("bookId") Long bookId, @PathVariable("indexNum") Integer indexNum, HttpServletRequest req, ModelMap modelMap) {
        BookContent bookContent = bookContentService.queryBookContent(bookId, indexNum);
        String indexName;
        if (bookContent == null) {
            bookContent = new BookContent();
            bookContent.setId(-1L);
            bookContent.setBookId(bookId);
            bookContent.setIndexNum(indexNum);
            bookContent.setContent(Constants.NO_CONTENT_DESC);
            indexName = "更新中。。。";
        } else {
            indexName = bookContentService.queryIndexNameByBookIdAndIndexNum(bookId, indexNum);
        }
        List<Integer> preAndNextIndexNum = bookContentService.queryPreAndNextIndexNum(bookId, indexNum);
        modelMap.put("nextIndexNum", preAndNextIndexNum.get(0));
        modelMap.put("preIndexNum", preAndNextIndexNum.get(1));
        bookContent.setContent(bookContent.getContent().replaceAll(Constants.CONTENT_AD_PATTERN, ""));
        modelMap.put("bookContent", bookContent);
        modelMap.put("indexName", indexName);
        Book basicBook = bookContentService.queryBaseInfo(bookId);
        if (basicBook.getCatid() <= Constants.MAX_NOVEL_CAT) {
            bookContent.setContent(StringEscapeUtils.unescapeHtml4(bookContent.getContent()));
        }
        String bookName = basicBook.getBookName();
        Integer catId = basicBook.getCatid();
        modelMap.put("bookName", bookName);
        modelMap.put("catId", catId);
     /*   SeoConfig seoConfig = (SeoConfig) req.getServletContext().getAttribute(Constants.SEO_CONFIG_KEY);
        Map<String,String> page = null;*/

 /*       modelMap.put("title",page.get("content.title").replaceAll("<bookName>",bookName).replaceAll("<indexName>",indexName));
        modelMap.put("keyword",page.get("content.keyword").replaceAll("<bookName>",bookName).replaceAll("<indexName>",indexName));
        modelMap.put("description",page.get("content.description").replaceAll("<bookName>",bookName).replaceAll("<indexName>",indexName));*/
        return bookContent;
    }

    /**
     * 书籍详情页
     */
    @ApiOperation(value = "图书的详情")
    @GetMapping(value = "detail")
    @ResponseBody

    public Book detail( Long bookId, @RequestParam(value = "token", required = false) String token, HttpServletRequest req, ModelMap modelMap) {
        //查询基本信息
        Book book = bookService.queryBaseInfo(bookId);
        //查询最新目录信息
        List<BookIndex> indexList = bookService.queryNewIndexList(bookId);

        int minIndexNum = 0;
        //查询最小目录号
        List<Integer> integers = bookService.queryMaxAndMinIndexNum(bookId);
        if (integers.size() > 1) {
            minIndexNum = integers.get(1);
        }


        BookVO bookvo = new BookVO();
        BeanUtils.copyProperties(book, bookvo);
        bookvo.setCateName(CatUtil.getCatNameById(bookvo.getCatid()));

        modelMap.put("bookId", bookId);
        modelMap.put("book", bookvo);
        modelMap.put("minIndexNum", minIndexNum);
        modelMap.put("indexList", indexList);
        if (indexList != null && indexList.size() > 0) {
            modelMap.put("lastIndexName", indexList.get(0).getIndexName());
            modelMap.put("lastIndexNum", indexList.get(0).getIndexNum());
        }
        return book ;
    }

}
