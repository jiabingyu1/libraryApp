package edu.xja.digitallibrary.common.response;

public interface Response {
    boolean SUCCESS = true;
    int SUCCESS_CODE = 10000;
}
