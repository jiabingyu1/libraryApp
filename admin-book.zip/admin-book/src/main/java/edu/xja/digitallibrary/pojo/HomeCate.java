package edu.xja.digitallibrary.pojo;

import java.util.List;

public class HomeCate {
    private Integer catId;
    private String catName;
    private List<Readbook> readbookList;

    public Integer getCatId() {
        return catId;
    }

    public void setCatId(Integer catId) {
        this.catId = catId;
    }

    public String getCatName() {
        return catName;
    }

    public void setCatName(String catName) {
        this.catName = catName;
    }

    public List<Readbook> getReadbookList() {
        return readbookList;
    }

    public void setReadbookList(List<Readbook> readbookList) {
        this.readbookList = readbookList;
    }
}
