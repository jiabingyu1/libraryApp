package edu.xja.digitallibrary.service.impl;

import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import edu.xja.digitallibrary.dao.ReadurlMapper;
import edu.xja.digitallibrary.pojo.Readurl;
import edu.xja.digitallibrary.service.ReadurlService;
@Service
public class ReadurlServiceImpl implements ReadurlService{

    @Resource
    private ReadurlMapper readurlMapper;

    @Override
    public int updateBatch(List<Readurl> list) {
        return readurlMapper.updateBatch(list);
    }

    @Override
    public int batchInsert(List<Readurl> list) {
        return readurlMapper.batchInsert(list);
    }

    @Override
    public int insertOrUpdate(Readurl record) {
        return readurlMapper.insertOrUpdate(record);
    }

    @Override
    public int insertOrUpdateSelective(Readurl record) {
        return readurlMapper.insertOrUpdateSelective(record);
    }

    @Override
    public Readurl findOneReadUrl(Readurl readurl) {
        return readurlMapper.selectOne(readurl);
    }

}
