package edu.xja.digitallibrary.service.impl;

import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import edu.xja.digitallibrary.dao.AudiocateMapper;
import edu.xja.digitallibrary.pojo.Audiocate;
import edu.xja.digitallibrary.service.AudiocateService;
@Service
public class AudiocateServiceImpl implements AudiocateService{

    @Resource
    private AudiocateMapper audiocateMapper;

    @Override
    public int updateBatch(List<Audiocate> list) {
        return audiocateMapper.updateBatch(list);
    }

    @Override
    public int batchInsert(List<Audiocate> list) {
        return audiocateMapper.batchInsert(list);
    }

    @Override
    public int insertOrUpdate(Audiocate record) {
        return audiocateMapper.insertOrUpdate(record);
    }

    @Override
    public int insertOrUpdateSelective(Audiocate record) {
        return audiocateMapper.insertOrUpdateSelective(record);
    }

    @Override
    public List<Audiocate> finaAllAudioCate() {
        return audiocateMapper.selectAll();
    }

}
