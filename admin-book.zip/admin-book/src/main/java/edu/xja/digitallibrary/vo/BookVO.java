package edu.xja.digitallibrary.vo;

import edu.xja.digitallibrary.pojo.Book;

public class BookVO extends Book {

    private String cateName;

    public String getCateName() {
        return cateName;
    }

    public void setCateName(String cateName) {
        this.cateName = cateName;
    }
}
