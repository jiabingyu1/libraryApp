package edu.xja.digitallibrary.service.impl;

import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import edu.xja.digitallibrary.pojo.Bookchapter;
import edu.xja.digitallibrary.dao.BookchapterMapper;
import edu.xja.digitallibrary.service.BookchapterService;
@Service
public class BookchapterServiceImpl implements BookchapterService{

    @Resource
    private BookchapterMapper bookchapterMapper;

    @Override
    public int updateBatch(List<Bookchapter> list) {
        return bookchapterMapper.updateBatch(list);
    }

    @Override
    public int batchInsert(List<Bookchapter> list) {
        return bookchapterMapper.batchInsert(list);
    }

    @Override
    public int insertOrUpdate(Bookchapter record) {
        return bookchapterMapper.insertOrUpdate(record);
    }

    @Override
    public int insertOrUpdateSelective(Bookchapter record) {
        return bookchapterMapper.insertOrUpdateSelective(record);
    }

    @Override
    public List<Bookchapter> searchAuChapter(Bookchapter record) {
        return bookchapterMapper.select(record);
    }

}
