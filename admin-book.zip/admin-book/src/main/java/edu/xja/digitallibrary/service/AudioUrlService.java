package edu.xja.digitallibrary.service;

import edu.xja.digitallibrary.pojo.AudioUrl;

import java.util.List;

public interface AudioUrlService {


    int updateBatch(List<AudioUrl> list);

    int batchInsert(List<AudioUrl> list);

    int insertOrUpdate(AudioUrl record);

    int insertOrUpdateSelective(AudioUrl record);

    AudioUrl findOneAuUrl(AudioUrl audioUrl);

}
