package edu.xja.library.rabbitmqtest;


import org.junit.runner.RunWith;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * author :  ring2
 * create:   2019/9/24 19:52
 **/
@SpringBootTest
@RunWith(SpringRunner.class)
public class RabbitMQ {


}
